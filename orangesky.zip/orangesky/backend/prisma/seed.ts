import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // Create admin user
  const hashedPassword = await bcrypt.hash('Admin123!', 12);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@orangeskysolutions.com' },
    update: {},
    create: {
      email: 'admin@orangeskysolutions.com',
      name: 'Admin User',
      password: hashedPassword,
      role: 'ADMIN',
    },
  });
  console.log('✅ Admin user created:', admin.email);

  // Create blog categories
  const categories = [
    { name: 'AI & Machine Learning', slug: 'ai-ml', description: 'Articles about AI and Machine Learning' },
    { name: 'Web Development', slug: 'web-development', description: 'Web development tips and tutorials' },
    { name: 'Cloud Engineering', slug: 'cloud-engineering', description: 'Cloud infrastructure and DevOps' },
    { name: 'Mobile Development', slug: 'mobile-development', description: 'iOS, Android, and cross-platform development' },
    { name: 'UI/UX Design', slug: 'ui-ux-design', description: 'Design principles and best practices' },
  ];

  for (const category of categories) {
    await prisma.blogCategory.upsert({
      where: { slug: category.slug },
      update: {},
      create: category,
    });
  }
  console.log('✅ Blog categories created');

  // Create blog tags
  const tags = [
    'AI', 'Machine Learning', 'React', 'Node.js', 'TypeScript', 
    'AWS', 'Azure', 'Docker', 'Kubernetes', 'Mobile', 
    'iOS', 'Android', 'Design', 'UX', 'Agile',
  ];

  for (const tag of tags) {
    await prisma.blogTag.upsert({
      where: { slug: tag.toLowerCase().replace(/\s+/g, '-') },
      update: {},
      create: {
        name: tag,
        slug: tag.toLowerCase().replace(/\s+/g, '-'),
      },
    });
  }
  console.log('✅ Blog tags created');

  // Create sample blog posts
  const aiCategory = await prisma.blogCategory.findUnique({ where: { slug: 'ai-ml' } });
  
  if (aiCategory) {
    await prisma.blog.upsert({
      where: { slug: 'human-centric-ai-designing-systems' },
      update: {},
      create: {
        title: 'Human-Centric AI: Designing Systems That Truly Understand',
        slug: 'human-centric-ai-designing-systems',
        excerpt: 'Explore how human-centric AI design creates more intuitive, empathetic, and effective systems that enhance human capabilities.',
        content: '<p>Artificial Intelligence has evolved beyond mere automation...</p>',
        coverImage: '/images/blog/human-centric-ai.jpg',
        status: 'PUBLISHED',
        publishedAt: new Date(),
        readTime: 8,
        authorId: admin.id,
        categoryId: aiCategory.id,
      },
    });
  }
  console.log('✅ Sample blog posts created');

  // Create sample job listings
  const jobs = [
    {
      title: 'Senior Full Stack Developer',
      slug: 'senior-full-stack-developer',
      department: 'Engineering',
      location: 'Remote / Hybrid',
      type: 'FULL_TIME' as const,
      experience: '5+ years',
      salary: '$120,000 - $160,000',
      description: 'We are looking for a Senior Full Stack Developer to join our growing team...',
      requirements: ['5+ years of experience', 'React/Next.js expertise', 'Node.js/Python backend', 'Cloud experience (AWS/Azure)'],
      benefits: ['Competitive salary', 'Health insurance', 'Remote work options', 'Learning budget'],
      status: 'ACTIVE' as const,
      featured: true,
      publishedAt: new Date(),
    },
    {
      title: 'AI/ML Engineer',
      slug: 'ai-ml-engineer',
      department: 'Engineering',
      location: 'Remote',
      type: 'FULL_TIME' as const,
      experience: '3+ years',
      salary: '$140,000 - $180,000',
      description: 'Join our AI team to build cutting-edge machine learning solutions...',
      requirements: ['3+ years ML experience', 'Python/TensorFlow/PyTorch', 'LLM experience preferred', 'Strong math background'],
      benefits: ['Competitive salary', 'Stock options', 'Conference budget', 'Flexible hours'],
      status: 'ACTIVE' as const,
      featured: true,
      publishedAt: new Date(),
    },
    {
      title: 'UI/UX Designer',
      slug: 'ui-ux-designer',
      department: 'Design',
      location: 'Remote / Hybrid',
      type: 'FULL_TIME' as const,
      experience: '3+ years',
      description: 'We are seeking a talented UI/UX Designer to create beautiful, user-centered designs...',
      requirements: ['3+ years design experience', 'Figma expertise', 'User research skills', 'Design system experience'],
      benefits: ['Competitive salary', 'Creative freedom', 'Modern equipment', 'Design community access'],
      status: 'ACTIVE' as const,
      featured: false,
      publishedAt: new Date(),
    },
  ];

  for (const job of jobs) {
    await prisma.jobListing.upsert({
      where: { slug: job.slug },
      update: {},
      create: job,
    });
  }
  console.log('✅ Sample job listings created');

  // Create sample case studies
  const caseStudies = [
    {
      title: 'TalentBridge: AI-Powered Recruitment Platform',
      slug: 'talentbridge-recruitment-platform',
      description: 'Revolutionizing talent acquisition with intelligent matching algorithms and automated screening.',
      content: '<p>TalentBridge partnered with us to transform their recruitment process...</p>',
      category: 'Recruitment Tech',
      client: 'TalentBridge Inc.',
      duration: '6 months',
      techStack: ['React', 'Node.js', 'PostgreSQL', 'OpenAI', 'AWS'],
      results: { efficiency: '75%', timeToHire: '60% reduction', satisfaction: '95%' },
      featured: true,
      publishedAt: new Date(),
    },
    {
      title: 'MediCareAI: Healthcare Analytics Platform',
      slug: 'medicareai-healthcare-platform',
      description: 'Empowering healthcare providers with AI-driven insights and predictive analytics.',
      content: '<p>MediCareAI needed a robust platform for healthcare data analysis...</p>',
      category: 'Healthcare',
      client: 'MediCare Solutions',
      duration: '8 months',
      techStack: ['Next.js', 'Python', 'TensorFlow', 'Azure', 'FHIR'],
      results: { accuracy: '92%', costReduction: '40%', patientOutcomes: '25% improvement' },
      featured: true,
      publishedAt: new Date(),
    },
  ];

  for (const caseStudy of caseStudies) {
    await prisma.caseStudy.upsert({
      where: { slug: caseStudy.slug },
      update: {},
      create: caseStudy,
    });
  }
  console.log('✅ Sample case studies created');

  console.log('🎉 Database seed completed!');
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
