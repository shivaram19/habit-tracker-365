import { z } from 'zod';

// FAQ schemas
export const createFAQSchema = z.object({
  body: z.object({
    question: z.string().min(10, 'Question must be at least 10 characters'),
    answer: z.string().min(20, 'Answer must be at least 20 characters'),
    category: z.string().min(1, 'Category is required'),
    order: z.number().int().min(0).optional(),
    isActive: z.boolean().optional(),
  }),
});

export const updateFAQSchema = z.object({
  params: z.object({
    id: z.string().min(1, 'FAQ ID is required'),
  }),
  body: z.object({
    question: z.string().min(10, 'Question must be at least 10 characters').optional(),
    answer: z.string().min(20, 'Answer must be at least 20 characters').optional(),
    category: z.string().min(1, 'Category is required').optional(),
    order: z.number().int().min(0).optional(),
    isActive: z.boolean().optional(),
  }),
});

export const listFAQsSchema = z.object({
  query: z.object({
    category: z.string().optional(),
    isActive: z.enum(['true', 'false']).optional(),
    page: z.string().regex(/^\d+$/).optional(),
    limit: z.string().regex(/^\d+$/).optional(),
  }),
});

// FAQ Category schemas
export const createFAQCategorySchema = z.object({
  body: z.object({
    name: z.string().min(2, 'Name must be at least 2 characters'),
    slug: z.string().min(2, 'Slug must be at least 2 characters').regex(/^[a-z0-9-]+$/, 'Slug must be lowercase with hyphens'),
    description: z.string().optional(),
    order: z.number().int().min(0).optional(),
    isActive: z.boolean().optional(),
  }),
});

export const updateFAQCategorySchema = z.object({
  params: z.object({
    id: z.string().min(1, 'Category ID is required'),
  }),
  body: z.object({
    name: z.string().min(2, 'Name must be at least 2 characters').optional(),
    slug: z.string().min(2, 'Slug must be at least 2 characters').regex(/^[a-z0-9-]+$/, 'Slug must be lowercase with hyphens').optional(),
    description: z.string().optional(),
    order: z.number().int().min(0).optional(),
    isActive: z.boolean().optional(),
  }),
});

export type CreateFAQInput = z.infer<typeof createFAQSchema>['body'];
export type UpdateFAQInput = z.infer<typeof updateFAQSchema>['body'];
export type CreateFAQCategoryInput = z.infer<typeof createFAQCategorySchema>['body'];
export type UpdateFAQCategoryInput = z.infer<typeof updateFAQCategorySchema>['body'];
