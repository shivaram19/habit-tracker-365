import { z } from 'zod';

export const createJobSchema = z.object({
  body: z.object({
    title: z.string().min(1, 'Title is required').max(200),
    department: z.string().min(1, 'Department is required'),
    location: z.string().min(1, 'Location is required'),
    type: z.enum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERNSHIP']),
    experience: z.string().min(1, 'Experience is required'),
    salary: z.string().optional(),
    description: z.string().min(1, 'Description is required'),
    requirements: z.array(z.string()).min(1, 'At least one requirement is needed'),
    benefits: z.array(z.string()).optional(),
    featured: z.boolean().optional(),
    status: z.enum(['DRAFT', 'ACTIVE']).optional(),
    closesAt: z.string().datetime().optional(),
  }),
});

export const updateJobSchema = z.object({
  params: z.object({
    id: z.string().min(1),
  }),
  body: z.object({
    title: z.string().min(1).max(200).optional(),
    department: z.string().optional(),
    location: z.string().optional(),
    type: z.enum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERNSHIP']).optional(),
    experience: z.string().optional(),
    salary: z.string().optional().nullable(),
    description: z.string().optional(),
    requirements: z.array(z.string()).optional(),
    benefits: z.array(z.string()).optional(),
    featured: z.boolean().optional(),
    status: z.enum(['DRAFT', 'ACTIVE', 'CLOSED']).optional(),
    closesAt: z.string().datetime().optional().nullable(),
  }),
});

export const applyJobSchema = z.object({
  params: z.object({
    id: z.string().min(1),
  }),
  body: z.object({
    name: z.string().min(2, 'Name is required'),
    email: z.string().email('Invalid email'),
    phone: z.string().optional(),
    resumeUrl: z.string().url('Invalid resume URL'),
    coverLetter: z.string().optional(),
    linkedinUrl: z.string().url().optional(),
    portfolioUrl: z.string().url().optional(),
  }),
});

export const listJobsSchema = z.object({
  query: z.object({
    page: z.string().regex(/^\d+$/).optional().default('1'),
    limit: z.string().regex(/^\d+$/).optional().default('10'),
    department: z.string().optional(),
    type: z.enum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERNSHIP']).optional(),
    status: z.enum(['DRAFT', 'ACTIVE', 'CLOSED']).optional(),
  }),
});

export type CreateJobInput = z.infer<typeof createJobSchema>['body'];
export type UpdateJobInput = z.infer<typeof updateJobSchema>['body'];
export type ApplyJobInput = z.infer<typeof applyJobSchema>['body'];
