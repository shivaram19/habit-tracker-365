import { z } from 'zod';

export const contactMessageSchema = z.object({
  body: z.object({
    name: z.string().min(2, 'Name is required'),
    email: z.string().email('Invalid email address'),
    phone: z.string().optional(),
    company: z.string().optional(),
    subject: z.string().min(1, 'Subject is required').max(200),
    message: z.string().min(10, 'Message must be at least 10 characters'),
    source: z.string().optional(),
  }),
});

export const newsletterSchema = z.object({
  body: z.object({
    email: z.string().email('Invalid email address'),
  }),
});

export type ContactMessageInput = z.infer<typeof contactMessageSchema>['body'];
export type NewsletterInput = z.infer<typeof newsletterSchema>['body'];
