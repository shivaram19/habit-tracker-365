import { Router, Request, Response } from 'express';
import slugify from 'slugify';
import prisma from '../lib/prisma.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, AppError } from '../middleware/errorHandler.js';
import { getBlogBySlugSchema, listBlogsSchema } from '../validators/blog.validator.js';

const router = Router();

// List published blogs (public)
router.get(
  '/',
  validate(listBlogsSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const category = req.query.category as string;
    const search = req.query.search as string;

    const where = {
      status: 'PUBLISHED' as const,
      ...(category && { category: { slug: category } }),
      ...(search && {
        OR: [
          { title: { contains: search, mode: 'insensitive' as const } },
          { excerpt: { contains: search, mode: 'insensitive' as const } },
        ],
      }),
    };

    const [blogs, total] = await Promise.all([
      prisma.blog.findMany({
        where,
        select: {
          id: true,
          title: true,
          slug: true,
          excerpt: true,
          coverImage: true,
          readTime: true,
          publishedAt: true,
          author: { select: { name: true } },
          category: { select: { name: true, slug: true } },
          tags: { select: { name: true, slug: true } },
        },
        orderBy: { publishedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.blog.count({ where }),
    ]);

    res.json({
      success: true,
      data: {
        blogs,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  })
);

// Get blog by slug (public)
router.get(
  '/:slug',
  validate(getBlogBySlugSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const { slug } = req.params;

    const blog = await prisma.blog.findFirst({
      where: { slug, status: 'PUBLISHED' },
      include: {
        author: { select: { name: true } },
        category: { select: { name: true, slug: true } },
        tags: { select: { name: true, slug: true } },
      },
    });

    if (!blog) {
      throw new AppError('Blog not found', 404);
    }

    res.json({ success: true, data: { blog } });
  })
);

// Get categories (public)
router.get(
  '/meta/categories',
  asyncHandler(async (req: Request, res: Response) => {
    const categories = await prisma.blogCategory.findMany({
      select: {
        id: true,
        name: true,
        slug: true,
        _count: { select: { blogs: true } },
      },
      orderBy: { name: 'asc' },
    });

    res.json({ success: true, data: { categories } });
  })
);

// Get recent blogs (public)
router.get(
  '/meta/recent',
  asyncHandler(async (req: Request, res: Response) => {
    const limit = parseInt(req.query.limit as string) || 5;

    const blogs = await prisma.blog.findMany({
      where: { status: 'PUBLISHED' },
      select: {
        id: true,
        title: true,
        slug: true,
        excerpt: true,
        coverImage: true,
        readTime: true,
        publishedAt: true,
        category: { select: { name: true, slug: true } },
      },
      orderBy: { publishedAt: 'desc' },
      take: limit,
    });

    res.json({ success: true, data: { blogs } });
  })
);

export default router;
