import { Router, Request, Response } from 'express';
import prisma from '../lib/prisma.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, AppError } from '../middleware/errorHandler.js';
import { listJobsSchema, applyJobSchema } from '../validators/career.validator.js';

const router = Router();

// List active jobs (public)
router.get(
  '/',
  validate(listJobsSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const department = req.query.department as string;
    const type = req.query.type as string;

    const where = {
      status: 'ACTIVE' as const,
      ...(department && { department }),
      ...(type && { type: type as any }),
    };

    const [jobs, total] = await Promise.all([
      prisma.jobListing.findMany({
        where,
        select: {
          id: true,
          title: true,
          slug: true,
          department: true,
          location: true,
          type: true,
          experience: true,
          featured: true,
          publishedAt: true,
        },
        orderBy: [{ featured: 'desc' }, { publishedAt: 'desc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.jobListing.count({ where }),
    ]);

    res.json({
      success: true,
      data: {
        jobs,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  })
);

// Get job by slug (public)
router.get(
  '/:slug',
  asyncHandler(async (req: Request, res: Response) => {
    const { slug } = req.params;

    const job = await prisma.jobListing.findFirst({
      where: { slug, status: 'ACTIVE' },
    });

    if (!job) {
      throw new AppError('Job not found', 404);
    }

    res.json({ success: true, data: { job } });
  })
);

// Apply for job (public)
router.post(
  '/:id/apply',
  validate(applyJobSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params;
    const applicationData = req.body;

    const job = await prisma.jobListing.findUnique({ where: { id } });
    if (!job || job.status !== 'ACTIVE') {
      throw new AppError('Job not found or no longer accepting applications', 404);
    }

    // Check for duplicate application
    const existingApplication = await prisma.jobApplication.findFirst({
      where: { jobId: id, email: applicationData.email },
    });

    if (existingApplication) {
      throw new AppError('You have already applied for this position', 400);
    }

    const application = await prisma.jobApplication.create({
      data: {
        jobId: id,
        ...applicationData,
      },
    });

    res.status(201).json({
      success: true,
      message: 'Application submitted successfully',
      data: { applicationId: application.id },
    });
  })
);

// Get departments (public)
router.get(
  '/meta/departments',
  asyncHandler(async (req: Request, res: Response) => {
    const departments = await prisma.jobListing.findMany({
      where: { status: 'ACTIVE' },
      select: { department: true },
      distinct: ['department'],
    });

    res.json({
      success: true,
      data: { departments: departments.map((d) => d.department) },
    });
  })
);

export default router;
