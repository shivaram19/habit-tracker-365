import { Router, Request, Response } from 'express';
import prisma from '../lib/prisma.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, AppError } from '../middleware/errorHandler.js';
import { contactMessageSchema, newsletterSchema } from '../validators/contact.validator.js';

const router = Router();

// Submit contact message (public)
router.post(
  '/',
  validate(contactMessageSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const messageData = req.body;

    const message = await prisma.contactMessage.create({
      data: messageData,
    });

    // TODO: Send notification email to admin
    // TODO: Send confirmation email to user

    res.status(201).json({
      success: true,
      message: 'Thank you for your message. We will get back to you soon.',
      data: { messageId: message.id },
    });
  })
);

// Subscribe to newsletter (public)
router.post(
  '/newsletter',
  validate(newsletterSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const { email } = req.body;

    const existingSubscriber = await prisma.newsletter.findUnique({
      where: { email },
    });

    if (existingSubscriber) {
      if (existingSubscriber.isSubscribed) {
        return res.json({
          success: true,
          message: 'You are already subscribed to our newsletter.',
        });
      }

      // Resubscribe
      await prisma.newsletter.update({
        where: { email },
        data: { isSubscribed: true },
      });

      return res.json({
        success: true,
        message: 'Welcome back! You have been resubscribed.',
      });
    }

    await prisma.newsletter.create({
      data: { email },
    });

    res.status(201).json({
      success: true,
      message: 'Thank you for subscribing to our newsletter!',
    });
  })
);

// Unsubscribe from newsletter (public)
router.delete(
  '/newsletter',
  validate(newsletterSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const { email } = req.body;

    const subscriber = await prisma.newsletter.findUnique({
      where: { email },
    });

    if (!subscriber) {
      throw new AppError('Email not found in our mailing list', 404);
    }

    await prisma.newsletter.update({
      where: { email },
      data: { isSubscribed: false },
    });

    res.json({
      success: true,
      message: 'You have been unsubscribed from our newsletter.',
    });
  })
);

export default router;
