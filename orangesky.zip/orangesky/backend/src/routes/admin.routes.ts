import { Router, Response } from 'express';
import slugify from 'slugify';
import prisma from '../lib/prisma.js';
import { authenticate, authorize, AuthRequest } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { asyncHandler, AppError } from '../middleware/errorHandler.js';
import { createBlogSchema, updateBlogSchema } from '../validators/blog.validator.js';
import { createJobSchema, updateJobSchema } from '../validators/career.validator.js';

const router = Router();

// All admin routes require authentication
router.use(authenticate);

// ================== DASHBOARD ==================

router.get(
  '/dashboard',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const [
      totalBlogs,
      totalJobs,
      totalMessages,
      recentMessages,
      recentApplications,
    ] = await Promise.all([
      prisma.blog.count(),
      prisma.jobListing.count({ where: { status: 'ACTIVE' } }),
      prisma.contactMessage.count({ where: { status: 'NEW' } }),
      prisma.contactMessage.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        select: { id: true, name: true, email: true, subject: true, createdAt: true },
      }),
      prisma.jobApplication.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { job: { select: { title: true } } },
      }),
    ]);

    res.json({
      success: true,
      data: {
        stats: { totalBlogs, totalJobs, totalMessages },
        recentMessages,
        recentApplications,
      },
    });
  })
);

// ================== BLOGS ==================

router.get(
  '/blogs',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const status = req.query.status as string;

    const where = status ? { status: status as any } : {};

    const [blogs, total] = await Promise.all([
      prisma.blog.findMany({
        where,
        include: {
          author: { select: { name: true } },
          category: { select: { name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.blog.count({ where }),
    ]);

    res.json({
      success: true,
      data: { blogs, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
    });
  })
);

router.post(
  '/blogs',
  authorize('ADMIN', 'EDITOR'),
  validate(createBlogSchema),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { title, tags, ...blogData } = req.body;
    const slug = slugify(title, { lower: true, strict: true });

    const existingBlog = await prisma.blog.findUnique({ where: { slug } });
    if (existingBlog) {
      throw new AppError('A blog with this title already exists', 400);
    }

    const blog = await prisma.blog.create({
      data: {
        title,
        slug,
        ...blogData,
        authorId: req.user!.id,
        publishedAt: blogData.status === 'PUBLISHED' ? new Date() : null,
      },
    });

    res.status(201).json({ success: true, data: { blog } });
  })
);

router.put(
  '/blogs/:id',
  authorize('ADMIN', 'EDITOR'),
  validate(updateBlogSchema),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { title, ...updateData } = req.body;

    const existingBlog = await prisma.blog.findUnique({ where: { id } });
    if (!existingBlog) {
      throw new AppError('Blog not found', 404);
    }

    let slug = existingBlog.slug;
    if (title && title !== existingBlog.title) {
      slug = slugify(title, { lower: true, strict: true });
    }

    const blog = await prisma.blog.update({
      where: { id },
      data: {
        ...(title && { title }),
        slug,
        ...updateData,
        ...(updateData.status === 'PUBLISHED' && !existingBlog.publishedAt && { publishedAt: new Date() }),
      },
    });

    res.json({ success: true, data: { blog } });
  })
);

router.delete(
  '/blogs/:id',
  authorize('ADMIN'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;

    await prisma.blog.delete({ where: { id } });

    res.json({ success: true, message: 'Blog deleted successfully' });
  })
);

// ================== CAREERS ==================

router.get(
  '/jobs',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;

    const [jobs, total] = await Promise.all([
      prisma.jobListing.findMany({
        include: { _count: { select: { applications: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.jobListing.count(),
    ]);

    res.json({
      success: true,
      data: { jobs, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
    });
  })
);

router.post(
  '/jobs',
  authorize('ADMIN', 'EDITOR'),
  validate(createJobSchema),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { title, ...jobData } = req.body;
    const slug = slugify(title, { lower: true, strict: true });

    const job = await prisma.jobListing.create({
      data: {
        title,
        slug,
        ...jobData,
        publishedAt: jobData.status === 'ACTIVE' ? new Date() : null,
      },
    });

    res.status(201).json({ success: true, data: { job } });
  })
);

router.put(
  '/jobs/:id',
  authorize('ADMIN', 'EDITOR'),
  validate(updateJobSchema),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { title, ...updateData } = req.body;

    const existingJob = await prisma.jobListing.findUnique({ where: { id } });
    if (!existingJob) {
      throw new AppError('Job not found', 404);
    }

    let slug = existingJob.slug;
    if (title && title !== existingJob.title) {
      slug = slugify(title, { lower: true, strict: true });
    }

    const job = await prisma.jobListing.update({
      where: { id },
      data: {
        ...(title && { title }),
        slug,
        ...updateData,
        ...(updateData.status === 'ACTIVE' && !existingJob.publishedAt && { publishedAt: new Date() }),
      },
    });

    res.json({ success: true, data: { job } });
  })
);

router.delete(
  '/jobs/:id',
  authorize('ADMIN'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;

    await prisma.jobListing.delete({ where: { id } });

    res.json({ success: true, message: 'Job deleted successfully' });
  })
);

// ================== APPLICATIONS ==================

router.get(
  '/applications',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const jobId = req.query.jobId as string;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;

    const where = jobId ? { jobId } : {};

    const [applications, total] = await Promise.all([
      prisma.jobApplication.findMany({
        where,
        include: { job: { select: { title: true } } },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.jobApplication.count({ where }),
    ]);

    res.json({
      success: true,
      data: { applications, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
    });
  })
);

// ================== MESSAGES ==================

router.get(
  '/messages',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const status = req.query.status as string;

    const where = status ? { status: status as any } : {};

    const [messages, total] = await Promise.all([
      prisma.contactMessage.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.contactMessage.count({ where }),
    ]);

    res.json({
      success: true,
      data: { messages, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
    });
  })
);

router.put(
  '/messages/:id/status',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { status } = req.body;

    const message = await prisma.contactMessage.update({
      where: { id },
      data: {
        status,
        ...(status === 'REPLIED' && { repliedAt: new Date() }),
      },
    });

    res.json({ success: true, data: { message } });
  })
);

// ================== FAQ MANAGEMENT ==================

// Get all FAQs (including inactive)
router.get(
  '/faqs',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const category = req.query.category as string;
    const isActive = req.query.isActive as string;

    const where: any = {};
    if (category) where.category = category;
    if (isActive !== undefined) where.isActive = isActive === 'true';

    const [faqs, total] = await Promise.all([
      prisma.fAQ.findMany({
        where,
        orderBy: [{ category: 'asc' }, { order: 'asc' }, { createdAt: 'desc' }],
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.fAQ.count({ where }),
    ]);

    res.json({
      success: true,
      data: { faqs, pagination: { page, limit, total, totalPages: Math.ceil(total / limit) } },
    });
  })
);

// Create FAQ
router.post(
  '/faqs',
  authorize('ADMIN', 'EDITOR'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { question, answer, category, order = 0, isActive = true } = req.body;

    const faq = await prisma.fAQ.create({
      data: { question, answer, category, order, isActive },
    });

    res.status(201).json({ success: true, data: { faq } });
  })
);

// Update FAQ
router.put(
  '/faqs/:id',
  authorize('ADMIN', 'EDITOR'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { question, answer, category, order, isActive } = req.body;

    const faq = await prisma.fAQ.update({
      where: { id },
      data: {
        ...(question && { question }),
        ...(answer && { answer }),
        ...(category && { category }),
        ...(order !== undefined && { order }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    res.json({ success: true, data: { faq } });
  })
);

// Delete FAQ
router.delete(
  '/faqs/:id',
  authorize('ADMIN'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    await prisma.fAQ.delete({ where: { id } });
    res.json({ success: true, message: 'FAQ deleted successfully' });
  })
);

// Get all FAQ categories
router.get(
  '/faq-categories',
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const categories = await prisma.fAQCategory.findMany({
      orderBy: { order: 'asc' },
    });
    res.json({ success: true, data: { categories } });
  })
);

// Create FAQ category
router.post(
  '/faq-categories',
  authorize('ADMIN'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { name, slug, description, order = 0, isActive = true } = req.body;

    const category = await prisma.fAQCategory.create({
      data: { name, slug, description, order, isActive },
    });

    res.status(201).json({ success: true, data: { category } });
  })
);

// Update FAQ category
router.put(
  '/faq-categories/:id',
  authorize('ADMIN'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const { name, slug, description, order, isActive } = req.body;

    const category = await prisma.fAQCategory.update({
      where: { id },
      data: {
        ...(name && { name }),
        ...(slug && { slug }),
        ...(description !== undefined && { description }),
        ...(order !== undefined && { order }),
        ...(isActive !== undefined && { isActive }),
      },
    });

    res.json({ success: true, data: { category } });
  })
);

// Delete FAQ category
router.delete(
  '/faq-categories/:id',
  authorize('ADMIN'),
  asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    await prisma.fAQCategory.delete({ where: { id } });
    res.json({ success: true, message: 'Category deleted successfully' });
  })
);

export default router;
