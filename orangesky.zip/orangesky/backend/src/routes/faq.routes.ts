import { Router, Request, Response } from 'express';
import prisma from '../lib/prisma';
import { asyncHandler } from '../middleware/errorHandler';
import { validate } from '../middleware/validate';
import { listFAQsSchema } from '../validators/faq.validator';

const router = Router();

// ============================================
// PUBLIC FAQ ROUTES
// ============================================

/**
 * GET /api/faqs
 * List all active FAQs grouped by category
 */
router.get(
  '/',
  validate(listFAQsSchema),
  asyncHandler(async (req: Request, res: Response) => {
    const { category } = req.query;

    const where: any = { isActive: true };
    if (category) {
      where.category = category as string;
    }

    const faqs = await prisma.fAQ.findMany({
      where,
      orderBy: [
        { category: 'asc' },
        { order: 'asc' },
        { createdAt: 'asc' },
      ],
    });

    // Group FAQs by category
    const grouped = faqs.reduce((acc: Record<string, typeof faqs>, faq) => {
      if (!acc[faq.category]) {
        acc[faq.category] = [];
      }
      acc[faq.category].push(faq);
      return acc;
    }, {});

    res.json({
      success: true,
      data: {
        faqs,
        grouped,
      },
    });
  })
);

/**
 * GET /api/faqs/categories
 * List all active FAQ categories
 */
router.get(
  '/categories',
  asyncHandler(async (_req: Request, res: Response) => {
    const categories = await prisma.fAQCategory.findMany({
      where: { isActive: true },
      orderBy: { order: 'asc' },
    });

    res.json({
      success: true,
      data: categories,
    });
  })
);

/**
 * GET /api/faqs/by-category/:slug
 * Get FAQs by category slug
 */
router.get(
  '/by-category/:slug',
  asyncHandler(async (req: Request, res: Response) => {
    const { slug } = req.params;

    const category = await prisma.fAQCategory.findUnique({
      where: { slug },
    });

    if (!category) {
      return res.status(404).json({
        success: false,
        error: 'Category not found',
      });
    }

    const faqs = await prisma.fAQ.findMany({
      where: {
        category: category.name,
        isActive: true,
      },
      orderBy: [{ order: 'asc' }, { createdAt: 'asc' }],
    });

    res.json({
      success: true,
      data: {
        category,
        faqs,
      },
    });
  })
);

export default router;
