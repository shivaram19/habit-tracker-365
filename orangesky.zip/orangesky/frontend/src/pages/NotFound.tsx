import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, ArrowLeft } from 'lucide-react';
import Button from '@/components/ui/Button';

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-hero">
      <div className="absolute inset-0">
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-sky-400/20 rounded-full blur-3xl" />
      </div>

      <div className="container-custom relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-8xl md:text-9xl font-heading font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-sunset-400 mb-6">
              404
            </h1>
            <h2 className="text-2xl md:text-3xl font-heading font-bold text-white mb-4">
              Page Not Found
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Oops! The page you're looking for doesn't exist or has been moved.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                variant="primary"
                size="lg"
                asLink
                to="/"
                leftIcon={<Home className="h-5 w-5" />}
              >
                Go Home
              </Button>
              <Button
                variant="outline"
                size="lg"
                onClick={() => window.history.back()}
                leftIcon={<ArrowLeft className="h-5 w-5" />}
              >
                Go Back
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
