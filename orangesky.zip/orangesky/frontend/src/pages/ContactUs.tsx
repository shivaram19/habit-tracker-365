import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock } from 'lucide-react';
import Section from '@/components/ui/Section';
import ContactForm from '@/components/forms/ContactForm';

const contactInfo = {
  us: {
    title: 'United States',
    phone: '+1 (XXX) XXX-XXXX',
    address: 'Your US Location',
    email: 'hello@orangeskysolutions.com',
  },
  india: {
    title: 'India',
    address: 'Your India Location',
    email: 'hello@orangeskysolutions.com',
  },
};

export default function ContactUs() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[40vh] flex items-center bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-sky-400/20 rounded-full blur-3xl" />
        </div>

        <div className="container-custom relative z-10 pt-32 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
                Contact Us - Get In Touch
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Have a project in mind? Let's discuss how we can help bring your vision to life.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <Section background="white">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-2xl font-heading font-bold text-gray-900 mb-2">
              Send us a message
            </h2>
            <p className="text-gray-600 mb-8">
              Fill out the form below and we'll get back to you within 24 hours.
            </p>
            <ContactForm />
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-2xl font-heading font-bold text-gray-900 mb-8">
              Our Offices
            </h2>

            {/* US Office */}
            <div className="bg-gray-50 rounded-2xl p-6 mb-6">
              <h3 className="font-heading font-bold text-lg text-gray-900 mb-4">
                {contactInfo.us.title}
              </h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3 text-gray-600">
                  <Phone className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <span>{contactInfo.us.phone}</span>
                </div>
                <div className="flex items-start gap-3 text-gray-600">
                  <MapPin className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <span>{contactInfo.us.address}</span>
                </div>
                <div className="flex items-start gap-3 text-gray-600">
                  <Mail className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <a href={`mailto:${contactInfo.us.email}`} className="hover:text-orange-500 transition-colors">
                    {contactInfo.us.email}
                  </a>
                </div>
              </div>
            </div>

            {/* India Office */}
            <div className="bg-gray-50 rounded-2xl p-6 mb-6">
              <h3 className="font-heading font-bold text-lg text-gray-900 mb-4">
                {contactInfo.india.title}
              </h3>
              <div className="space-y-3">
                <div className="flex items-start gap-3 text-gray-600">
                  <MapPin className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <span>{contactInfo.india.address}</span>
                </div>
                <div className="flex items-start gap-3 text-gray-600">
                  <Mail className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <a href={`mailto:${contactInfo.india.email}`} className="hover:text-orange-500 transition-colors">
                    {contactInfo.india.email}
                  </a>
                </div>
              </div>
            </div>

            {/* Business Hours */}
            <div className="bg-orange-50 rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="h-5 w-5 text-orange-500" />
                <h3 className="font-heading font-bold text-lg text-gray-900">
                  Business Hours
                </h3>
              </div>
              <div className="space-y-2 text-gray-600">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span>9:00 AM - 6:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span>10:00 AM - 4:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span>Closed</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </Section>

      {/* Map Section (Placeholder) */}
      <section className="h-96 bg-gray-200">
        <div className="h-full flex items-center justify-center text-gray-500">
          <p>Map Integration - Add your preferred map provider</p>
        </div>
      </section>
    </>
  );
}
