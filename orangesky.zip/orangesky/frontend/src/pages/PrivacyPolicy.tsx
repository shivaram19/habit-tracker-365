import { motion } from 'framer-motion';
import Section from '@/components/ui/Section';

export default function PrivacyPolicy() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[30vh] flex items-center bg-gradient-hero overflow-hidden">
        <div className="container-custom relative z-10 pt-32 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl font-heading font-bold text-white mb-4">
                Privacy Policy
              </h1>
              <p className="text-gray-300">Last Updated: January 27, 2026</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <Section background="white">
        <div className="max-w-4xl mx-auto prose-custom">
          <h2>1. Information We Collect</h2>
          <p>
            Orange Sky Solutions ("we", "our", or "us") collects information you provide directly to us, such as when you fill out a contact form, subscribe to our newsletter, or communicate with us.
          </p>

          <h3>Personal Information</h3>
          <p>We may collect the following types of personal information:</p>
          <ul>
            <li>Name and email address</li>
            <li>Phone number</li>
            <li>Company name and job title</li>
            <li>Project requirements and preferences</li>
            <li>Any other information you choose to provide</li>
          </ul>

          <h3>Automatically Collected Information</h3>
          <p>When you visit our website, we automatically collect certain information, including:</p>
          <ul>
            <li>Device and browser information</li>
            <li>IP address</li>
            <li>Pages visited and time spent on pages</li>
            <li>Referring website addresses</li>
          </ul>

          <h2>2. How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul>
            <li>Respond to your inquiries and provide customer support</li>
            <li>Send you newsletters and marketing communications (with your consent)</li>
            <li>Improve our website and services</li>
            <li>Analyze usage patterns and trends</li>
            <li>Protect against fraudulent or illegal activity</li>
          </ul>

          <h2>3. Information Sharing</h2>
          <p>
            We do not sell, trade, or otherwise transfer your personal information to third parties except as described in this policy. We may share your information with:
          </p>
          <ul>
            <li>Service providers who assist in our operations</li>
            <li>Professional advisors (lawyers, accountants)</li>
            <li>Law enforcement when required by law</li>
          </ul>

          <h2>4. Data Security</h2>
          <p>
            We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet is 100% secure.
          </p>

          <h2>5. Your Rights</h2>
          <p>Depending on your location, you may have the following rights:</p>
          <ul>
            <li>Access to your personal data</li>
            <li>Correction of inaccurate data</li>
            <li>Deletion of your data</li>
            <li>Objection to processing</li>
            <li>Data portability</li>
          </ul>

          <h2>6. Cookies</h2>
          <p>
            We use cookies and similar tracking technologies to track activity on our website and store certain information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
          </p>

          <h2>7. Third-Party Links</h2>
          <p>
            Our website may contain links to third-party websites. We are not responsible for the privacy practices or content of these third-party sites.
          </p>

          <h2>8. Children's Privacy</h2>
          <p>
            Our services are not directed to individuals under the age of 18. We do not knowingly collect personal information from children.
          </p>

          <h2>9. Changes to This Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
          </p>

          <h2>10. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
          </p>
          <ul>
            <li>Email: hello@orangeskysolutions.com</li>
            <li>Website: www.orangeskysolutions.com</li>
          </ul>
        </div>
      </Section>
    </>
  );
}
