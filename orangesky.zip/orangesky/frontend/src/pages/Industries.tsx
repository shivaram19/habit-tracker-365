import { motion } from 'framer-motion';
import { ArrowRight, TrendingUp, Users, Target } from 'lucide-react';
import Button from '@/components/ui/Button';
import Section from '@/components/ui/Section';
import SectionHeading from '@/components/ui/SectionHeading';
import StatCard from '@/components/ui/StatCard';

const industries = [
  {
    id: 'healthcare',
    title: 'AI-Powered Healthcare Platform Development',
    description: 'We design secure, scalable, and intelligent digital healthcare solutions',
    tags: ['healthcare', 'software', 'digital health', 'IT solutions'],
    results: [
      { value: '5X', label: 'Revenue Growth' },
      { value: '7X', label: 'Lead Generation' },
      { value: '89%', label: 'Traffic Increase' },
    ],
  },
  {
    id: 'real-estate',
    title: 'Custom Real Estate IT Solutions Company',
    description: 'We design secure, scalable, and intelligent digital real estate solutions.',
    tags: ['AI-Driven Real Estate'],
    results: [
      { value: '5X', label: 'Revenue Growth' },
      { value: '7X', label: 'Lead Generation' },
      { value: '89%', label: 'Traffic Increase' },
    ],
  },
  {
    id: 'fintech',
    title: 'FinTech Innovation Solutions',
    description: 'We build secure, compliant, and innovative financial technology solutions',
    tags: ['AI-Driven FinTech'],
    results: [
      { value: '4X', label: 'Transaction Speed' },
      { value: '99.9%', label: 'Uptime' },
      { value: '80%', label: 'Cost Reduction' },
    ],
  },
];

export default function Industries() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-sky-400/20 rounded-full blur-3xl" />
        </div>

        <div className="container-custom relative z-10 pt-32 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
                Industries We Transform
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                From healthcare to fintech, we deliver cutting-edge solutions that revolutionize entire industries. Discover how we've helped businesses across 15+ sectors achieve digital excellence.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button variant="primary" size="lg" asLink to="#industries">
                  Explore Industries
                </Button>
                <Button variant="outline" size="lg" asLink to="/case-studies">
                  View Case Studies
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <Section background="white">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: '15+', label: 'Projects Delivered' },
            { value: '5+', label: 'Industries Served' },
            { value: '30+', label: 'Team Members' },
            { value: '92%', label: 'Happy Clients' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <StatCard value={stat.value} label={stat.label} />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Industry Solutions Section */}
      <Section background="gray" id="industries">
        <SectionHeading
          title="Industry Solutions"
          description="Discover how we've transformed businesses across diverse industries with innovative technology solutions tailored to each sector's unique challenges and opportunities."
        />

        <div className="space-y-8">
          {industries.map((industry, index) => (
            <motion.div
              key={industry.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl overflow-hidden border border-gray-200 hover:shadow-lg transition-all"
            >
              <div className="grid grid-cols-1 lg:grid-cols-3">
                {/* Content */}
                <div className="lg:col-span-2 p-8">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {industry.tags.map((tag) => (
                      <span
                        key={tag}
                        className="px-3 py-1 bg-orange-100 text-orange-600 text-xs rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-2xl font-heading font-bold text-gray-900 mb-3">
                    {industry.title}
                  </h3>
                  <p className="text-gray-600 mb-6">{industry.description}</p>
                  <Button variant="outline" size="md">
                    Explore Solutions
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>

                {/* Results */}
                <div className="bg-gray-50 p-8 flex flex-col justify-center">
                  <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-4">
                    Results
                  </h4>
                  <div className="space-y-4">
                    {industry.results.map((result) => (
                      <div key={result.label} className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                          <TrendingUp className="h-5 w-5 text-orange-500" />
                        </div>
                        <div>
                          <p className="text-xl font-bold text-gray-900">{result.value}</p>
                          <p className="text-sm text-gray-500">{result.label}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="white">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-gray-900 to-gray-800 p-8 md:p-12 lg:p-16">
          <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-5" />
          <div className="relative z-10 text-center max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              Ready to Transform Your Industry?
            </h2>
            <p className="text-gray-300 text-lg mb-8">
              Join the industry leaders who've chosen Orange Sky Solutions to revolutionize their business. Let's discuss how we can create innovative solutions for your specific industry needs.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button variant="primary" size="lg" asLink to="/contact-us">
                Schedule Consultation
              </Button>
              <Button
                variant="outline"
                size="lg"
                asLink
                to="/case-studies"
                className="border-white text-white hover:bg-white hover:text-gray-900"
              >
                View All Case Studies
              </Button>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
