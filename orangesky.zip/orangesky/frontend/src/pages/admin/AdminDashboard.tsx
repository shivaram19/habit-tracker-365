import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  FileText, 
  Briefcase, 
  MessageSquare, 
  Users, 
  TrendingUp,
  Eye,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import Section from '@/components/ui/Section';
import Button from '@/components/ui/Button';

const stats = [
  { 
    title: 'Total Views', 
    value: '24,532', 
    change: '+12.5%', 
    trend: 'up',
    icon: Eye 
  },
  { 
    title: 'Blog Posts', 
    value: '47', 
    change: '+3 this month', 
    trend: 'up',
    icon: FileText 
  },
  { 
    title: 'Job Applications', 
    value: '156', 
    change: '+23.1%', 
    trend: 'up',
    icon: Briefcase 
  },
  { 
    title: 'Messages', 
    value: '38', 
    change: '-5.2%', 
    trend: 'down',
    icon: MessageSquare 
  },
];

const recentActivity = [
  { type: 'blog', action: 'New blog post published', title: 'Future of AI in Software Development', time: '2 hours ago' },
  { type: 'job', action: 'New application received', title: 'Senior Full Stack Developer', time: '4 hours ago' },
  { type: 'message', action: 'Contact form submission', title: 'Project Inquiry - Healthcare Platform', time: '6 hours ago' },
  { type: 'blog', action: 'Blog post updated', title: 'Cloud Engineering Best Practices', time: '1 day ago' },
  { type: 'job', action: 'Job posting created', title: 'DevOps Engineer', time: '2 days ago' },
];

export default function AdminDashboard() {
  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-gray-900 mb-2">
          Dashboard
        </h1>
        <p className="text-gray-600">
          Welcome back! Here's an overview of your website's performance.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-2xl border border-gray-200 p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <stat.icon className="h-6 w-6 text-orange-500" />
              </div>
              <span className={`flex items-center text-sm font-medium ${
                stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.change}
                {stat.trend === 'up' ? (
                  <ArrowUpRight className="h-4 w-4 ml-1" />
                ) : (
                  <ArrowDownRight className="h-4 w-4 ml-1" />
                )}
              </span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
            <p className="text-gray-500 text-sm">{stat.title}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-heading font-bold text-gray-900">
              Recent Activity
            </h2>
            <Button variant="ghost" size="sm">
              View All
            </Button>
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  activity.type === 'blog' ? 'bg-blue-100 text-blue-600' :
                  activity.type === 'job' ? 'bg-green-100 text-green-600' :
                  'bg-orange-100 text-orange-600'
                }`}>
                  {activity.type === 'blog' && <FileText className="h-5 w-5" />}
                  {activity.type === 'job' && <Briefcase className="h-5 w-5" />}
                  {activity.type === 'message' && <MessageSquare className="h-5 w-5" />}
                </div>
                <div className="flex-1">
                  <p className="text-sm text-gray-500">{activity.action}</p>
                  <p className="font-medium text-gray-900">{activity.title}</p>
                </div>
                <span className="text-sm text-gray-400">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6">
          <h2 className="text-lg font-heading font-bold text-gray-900 mb-6">
            Quick Actions
          </h2>
          <div className="space-y-3">
            <Button variant="primary" className="w-full justify-start" asLink to="/admin/blogs/new">
              <FileText className="h-5 w-5 mr-3" />
              Create New Blog Post
            </Button>
            <Button variant="outline" className="w-full justify-start" asLink to="/admin/careers/new">
              <Briefcase className="h-5 w-5 mr-3" />
              Post New Job
            </Button>
            <Button variant="outline" className="w-full justify-start" asLink to="/admin/messages">
              <MessageSquare className="h-5 w-5 mr-3" />
              View Messages
            </Button>
          </div>

          <hr className="my-6 border-gray-200" />

          <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-4">
            System Status
          </h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">API Status</span>
              <span className="flex items-center text-green-600">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                Operational
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Database</span>
              <span className="flex items-center text-green-600">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-2" />
                Connected
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Last Backup</span>
              <span className="text-gray-500">Today, 03:00 AM</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
