import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  HelpCircle,
  Eye,
  EyeOff,
  ChevronDown,
  X,
  Save,
  FolderPlus,
} from 'lucide-react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import Badge from '@/components/ui/Badge';
import { api } from '@/lib/api';
import toast from 'react-hot-toast';

interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  order: number;
  isActive: boolean;
  createdAt: string;
}

interface FAQCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  order: number;
  isActive: boolean;
}

// Demo data for development (until backend is connected)
const demoFAQs: FAQ[] = [
  {
    id: '1',
    question: 'What is an MVP and why do startups need it?',
    answer: 'MVP is minimal version to validate core idea with real users. Takes 8–12 weeks instead of long development cycles. 73% of MVPs built helped raise funding.',
    category: 'MVP Development',
    order: 0,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: '2',
    question: 'How long does it take to build an MVP?',
    answer: '8–12 weeks (rush = 6 weeks; complex = 14–16 weeks).',
    category: 'MVP Development',
    order: 1,
    isActive: true,
    createdAt: new Date().toISOString(),
  },
];

const demoCategories: FAQCategory[] = [
  { id: '1', name: 'MVP Development', slug: 'mvp-development', order: 0, isActive: true },
  { id: '2', name: 'Web Development', slug: 'web-development', order: 1, isActive: true },
  { id: '3', name: 'Cloud Engineering', slug: 'cloud-engineering', order: 2, isActive: true },
  { id: '4', name: 'Mobile Development', slug: 'mobile-development', order: 3, isActive: true },
  { id: '5', name: 'AI & Machine Learning', slug: 'ai-ml', order: 4, isActive: true },
  { id: '6', name: 'UI/UX Design', slug: 'ui-ux-design', order: 5, isActive: true },
];

export default function AdminFAQs() {
  const [faqs, setFaqs] = useState<FAQ[]>(demoFAQs);
  const [categories, setCategories] = useState<FAQCategory[]>(demoCategories);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [showActiveOnly, setShowActiveOnly] = useState(false);
  
  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingFaq, setEditingFaq] = useState<FAQ | null>(null);
  
  // Form states
  const [formData, setFormData] = useState({
    question: '',
    answer: '',
    category: '',
    order: 0,
    isActive: true,
  });
  
  const [categoryFormData, setCategoryFormData] = useState({
    name: '',
    slug: '',
    description: '',
    order: 0,
    isActive: true,
  });

  // Filter FAQs
  const filteredFaqs = faqs.filter((faq) => {
    const matchesSearch =
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || faq.category === selectedCategory;
    const matchesActive = !showActiveOnly || faq.isActive;
    return matchesSearch && matchesCategory && matchesActive;
  });

  // Group by category for display
  const groupedFaqs = filteredFaqs.reduce((acc, faq) => {
    if (!acc[faq.category]) acc[faq.category] = [];
    acc[faq.category].push(faq);
    return acc;
  }, {} as Record<string, FAQ[]>);

  const resetForm = () => {
    setFormData({ question: '', answer: '', category: '', order: 0, isActive: true });
    setEditingFaq(null);
  };

  const handleOpenAddModal = () => {
    resetForm();
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (faq: FAQ) => {
    setFormData({
      question: faq.question,
      answer: faq.answer,
      category: faq.category,
      order: faq.order,
      isActive: faq.isActive,
    });
    setEditingFaq(faq);
    setIsAddModalOpen(true);
  };

  const handleSaveFaq = () => {
    if (!formData.question || !formData.answer || !formData.category) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingFaq) {
      // Update existing FAQ
      setFaqs((prev) =>
        prev.map((faq) =>
          faq.id === editingFaq.id
            ? { ...faq, ...formData }
            : faq
        )
      );
      toast.success('FAQ updated successfully');
    } else {
      // Create new FAQ
      const newFaq: FAQ = {
        id: Date.now().toString(),
        ...formData,
        createdAt: new Date().toISOString(),
      };
      setFaqs((prev) => [...prev, newFaq]);
      toast.success('FAQ created successfully');
    }

    setIsAddModalOpen(false);
    resetForm();
  };

  const handleDeleteFaq = (id: string) => {
    if (!confirm('Are you sure you want to delete this FAQ?')) return;
    setFaqs((prev) => prev.filter((faq) => faq.id !== id));
    toast.success('FAQ deleted successfully');
  };

  const handleToggleActive = (id: string) => {
    setFaqs((prev) =>
      prev.map((faq) =>
        faq.id === id ? { ...faq, isActive: !faq.isActive } : faq
      )
    );
  };

  const handleSaveCategory = () => {
    if (!categoryFormData.name || !categoryFormData.slug) {
      toast.error('Please fill in name and slug');
      return;
    }

    const newCategory: FAQCategory = {
      id: Date.now().toString(),
      ...categoryFormData,
    };
    setCategories((prev) => [...prev, newCategory]);
    toast.success('Category created successfully');
    setIsCategoryModalOpen(false);
    setCategoryFormData({ name: '', slug: '', description: '', order: 0, isActive: true });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-heading font-bold text-gray-900">FAQ Management</h1>
          <p className="text-gray-500 mt-1">Manage frequently asked questions</p>
        </div>
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => setIsCategoryModalOpen(true)}
          >
            <FolderPlus className="w-4 h-4 mr-2" />
            Add Category
          </Button>
          <Button onClick={handleOpenAddModal}>
            <Plus className="w-4 h-4 mr-2" />
            Add FAQ
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-soft border border-gray-100 p-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search FAQs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>
          <Select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full sm:w-48"
          >
            <option value="">All Categories</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.name}>
                {cat.name}
              </option>
            ))}
          </Select>
          <Button
            variant={showActiveOnly ? 'primary' : 'ghost'}
            onClick={() => setShowActiveOnly(!showActiveOnly)}
          >
            <Eye className="w-4 h-4 mr-2" />
            Active Only
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-soft border border-gray-100">
          <p className="text-sm text-gray-500">Total FAQs</p>
          <p className="text-2xl font-bold text-gray-900">{faqs.length}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-soft border border-gray-100">
          <p className="text-sm text-gray-500">Active</p>
          <p className="text-2xl font-bold text-green-600">
            {faqs.filter((f) => f.isActive).length}
          </p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-soft border border-gray-100">
          <p className="text-sm text-gray-500">Inactive</p>
          <p className="text-2xl font-bold text-gray-400">
            {faqs.filter((f) => !f.isActive).length}
          </p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-soft border border-gray-100">
          <p className="text-sm text-gray-500">Categories</p>
          <p className="text-2xl font-bold text-orange-500">{categories.length}</p>
        </div>
      </div>

      {/* FAQ List by Category */}
      <div className="space-y-6">
        {Object.entries(groupedFaqs).map(([category, categoryFaqs]) => (
          <motion.div
            key={category}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl shadow-soft border border-gray-100 overflow-hidden"
          >
            <div className="bg-gray-50 px-6 py-4 border-b border-gray-100 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <HelpCircle className="w-5 h-5 text-orange-500" />
                <h3 className="font-semibold text-gray-900">{category}</h3>
                <Badge variant="secondary">{categoryFaqs.length}</Badge>
              </div>
            </div>
            <div className="divide-y divide-gray-100">
              {categoryFaqs.map((faq) => (
                <div
                  key={faq.id}
                  className={`p-6 hover:bg-gray-50 transition-colors ${
                    !faq.isActive ? 'opacity-50' : ''
                  }`}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-medium text-gray-900">{faq.question}</h4>
                        {!faq.isActive && (
                          <Badge variant="secondary">Inactive</Badge>
                        )}
                      </div>
                      <p className="text-gray-600 text-sm line-clamp-2">{faq.answer}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleActive(faq.id)}
                        className={`p-2 rounded-lg transition-colors ${
                          faq.isActive
                            ? 'text-green-600 hover:bg-green-50'
                            : 'text-gray-400 hover:bg-gray-100'
                        }`}
                        title={faq.isActive ? 'Deactivate' : 'Activate'}
                      >
                        {faq.isActive ? (
                          <Eye className="w-4 h-4" />
                        ) : (
                          <EyeOff className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        onClick={() => handleOpenEditModal(faq)}
                        className="p-2 text-gray-400 hover:text-orange-500 hover:bg-orange-50 rounded-lg transition-colors"
                        title="Edit"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteFaq(faq.id)}
                        className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        ))}

        {Object.keys(groupedFaqs).length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl shadow-soft border border-gray-100">
            <HelpCircle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No FAQs found</h3>
            <p className="text-gray-500 mb-4">
              {searchQuery || selectedCategory
                ? 'Try adjusting your filters'
                : 'Get started by adding your first FAQ'}
            </p>
            {!searchQuery && !selectedCategory && (
              <Button onClick={handleOpenAddModal}>
                <Plus className="w-4 h-4 mr-2" />
                Add FAQ
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Add/Edit FAQ Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/50"
              onClick={() => setIsAddModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-heading font-bold">
                  {editingFaq ? 'Edit FAQ' : 'Add New FAQ'}
                </h2>
                <button
                  onClick={() => setIsAddModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Question *
                  </label>
                  <Input
                    value={formData.question}
                    onChange={(e) =>
                      setFormData({ ...formData, question: e.target.value })
                    }
                    placeholder="Enter the question..."
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Answer *
                  </label>
                  <Textarea
                    value={formData.answer}
                    onChange={(e) =>
                      setFormData({ ...formData, answer: e.target.value })
                    }
                    placeholder="Enter the answer..."
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Category *
                    </label>
                    <Select
                      value={formData.category}
                      onChange={(e) =>
                        setFormData({ ...formData, category: e.target.value })
                      }
                    >
                      <option value="">Select category...</option>
                      {categories.map((cat) => (
                        <option key={cat.id} value={cat.name}>
                          {cat.name}
                        </option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Display Order
                    </label>
                    <Input
                      type="number"
                      value={formData.order}
                      onChange={(e) =>
                        setFormData({ ...formData, order: parseInt(e.target.value) || 0 })
                      }
                      min={0}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="isActive"
                    checked={formData.isActive}
                    onChange={(e) =>
                      setFormData({ ...formData, isActive: e.target.checked })
                    }
                    className="rounded border-gray-300 text-orange-500 focus:ring-orange-500"
                  />
                  <label htmlFor="isActive" className="text-sm text-gray-700">
                    Active (visible on public FAQ page)
                  </label>
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-gray-100">
                <Button
                  variant="ghost"
                  onClick={() => setIsAddModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button onClick={handleSaveFaq}>
                  <Save className="w-4 h-4 mr-2" />
                  {editingFaq ? 'Update FAQ' : 'Create FAQ'}
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {/* Add Category Modal */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/50"
              onClick={() => setIsCategoryModalOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative bg-white rounded-2xl shadow-xl w-full max-w-md p-6"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-heading font-bold">Add Category</h2>
                <button
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name *
                  </label>
                  <Input
                    value={categoryFormData.name}
                    onChange={(e) => {
                      const name = e.target.value;
                      const slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
                      setCategoryFormData({ ...categoryFormData, name, slug });
                    }}
                    placeholder="e.g., Web Development"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Slug *
                  </label>
                  <Input
                    value={categoryFormData.slug}
                    onChange={(e) =>
                      setCategoryFormData({ ...categoryFormData, slug: e.target.value })
                    }
                    placeholder="e.g., web-development"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <Textarea
                    value={categoryFormData.description}
                    onChange={(e) =>
                      setCategoryFormData({ ...categoryFormData, description: e.target.value })
                    }
                    placeholder="Brief description of this category..."
                    rows={2}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-gray-100">
                <Button
                  variant="ghost"
                  onClick={() => setIsCategoryModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button onClick={handleSaveCategory}>
                  <Save className="w-4 h-4 mr-2" />
                  Create Category
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      )}
    </div>
  );
}
