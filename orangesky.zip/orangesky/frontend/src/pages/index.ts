// Marketing pages
export { default as Home } from './Home';
export { default as Industries } from './Industries';
export { default as Careers } from './Careers';
export { default as ContactUs } from './ContactUs';
export { default as Blogs } from './Blogs';
export { default as BlogPost } from './BlogPost';
export { default as FAQs } from './FAQs';
export { default as PrivacyPolicy } from './PrivacyPolicy';
export { default as TermsConditions } from './TermsConditions';
export { default as NotFound } from './NotFound';

// Service pages
export { 
  MVPDevelopment,
  WebDevelopment,
  CloudEngineering,
  DataAnalytics,
  MobileAppDevelopment,
  UIUXDesigning,
  EnterpriseAISolutions
} from './services';

// Admin pages
export {
  AdminDashboard,
  AdminLogin,
  AdminBlogs,
  AdminCareers,
  AdminFAQs
} from './admin';
