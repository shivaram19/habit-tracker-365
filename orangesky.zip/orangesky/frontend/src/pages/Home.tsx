import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Bot, FileText, BarChart3, Mic } from 'lucide-react';
import Button from '@/components/ui/Button';
import Section from '@/components/ui/Section';
import SectionHeading from '@/components/ui/SectionHeading';
import StatCard from '@/components/ui/StatCard';
import ServiceCard from '@/components/cards/ServiceCard';
import BlogCard from '@/components/cards/BlogCard';
import CaseStudyCard from '@/components/cards/CaseStudyCard';
import { services, getRecentBlogs, caseStudies } from '@/data';

// Animation variants
const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.5 },
};

const stagger = {
  animate: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

export default function Home() {
  const recentBlogs = getRecentBlogs(3);

  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center bg-gradient-hero overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-sky-400/20 rounded-full blur-3xl" />
        </div>

        <div className="container-custom relative z-10 pt-24 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-flex items-center gap-2 px-4 py-2 bg-orange-500/10 text-orange-400 rounded-full text-sm font-medium mb-6">
                <Sparkles className="h-4 w-4" />
                AI-Powered Digital Solutions
              </span>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6 leading-tight">
                We Build AI Custom Solutions
              </h1>
              
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                We build MVPs and enterprise-grade AI products with measurable impact.
                Fast. Secure. Scalable.
              </p>

              <div className="flex flex-wrap justify-center gap-4 mb-12">
                <Button variant="primary" size="lg" asLink to="/mvp-development">
                  AI MVP Solutions
                </Button>
                <Button variant="outline" size="lg" asLink to="/contact-us">
                  Get Your Free Strategy Call
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>

              {/* Quick service links */}
              <div className="flex flex-wrap justify-center gap-3">
                {['Mobile App Development', 'Website Development', 'Cloud Engineering'].map((service) => (
                  <Link
                    key={service}
                    to={`/${service.toLowerCase().replace(/\s+/g, '-')}`}
                    className="px-4 py-2 bg-white/5 hover:bg-white/10 text-gray-300 rounded-full text-sm transition-colors"
                  >
                    {service}
                  </Link>
                ))}
              </div>
            </motion.div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center"
          >
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-1.5 h-3 bg-white/50 rounded-full mt-2"
            />
          </motion.div>
        </div>
      </section>

      {/* AI Expertise Section */}
      <Section background="white">
        <SectionHeading
          title="AI Expertise That Redefines Your Workflow"
          description="We build custom AI solutions that simplify workflows, accelerate decisions, and drive innovation with AI Assistants, Content Generation, Analytics, and Voice Solutions."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { icon: Bot, title: 'AI Assistant', desc: 'AI is online and ready to help' },
            { icon: FileText, title: 'AI Content Generator', desc: 'Blog Posts, Email Campaigns, Code Generation' },
            { icon: BarChart3, title: 'AI Analytics Dashboard', desc: 'Process Efficiency, AI Accuracy, Cost Savings' },
            { icon: Mic, title: 'AI Voice Assistant', desc: 'Voice-enabled AI solutions' },
          ].map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="p-6 bg-gray-50 rounded-2xl border border-gray-100 hover:border-orange-200 hover:shadow-lg transition-all"
            >
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4">
                <item.icon className="h-6 w-6 text-orange-500" />
              </div>
              <h3 className="font-heading font-bold text-gray-900 mb-2">{item.title}</h3>
              <p className="text-sm text-gray-600">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Our Expertise Section */}
      <Section background="gray">
        <SectionHeading
          title="Our Expertise"
          description="We create custom software solutions that make business ideas actionable, streamline processes, reduce cost, and achieve scalable business growth."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.slice(0, 6).map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <ServiceCard
                title={service.title}
                description={service.shortDescription}
                icon={<service.icon className="h-6 w-6" />}
                href={service.href}
                variant={index === 0 ? 'featured' : 'default'}
              />
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" asLink to="/enterprise-ai-solutions">
            View All Services
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </Section>

      {/* Products Section */}
      <Section background="white">
        <SectionHeading
          title="Our Products"
          description="Innovative solutions crafted in-house, pushing the boundaries of what's possible in digital experiences."
        />

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              name: 'SkyConnect',
              desc: 'A next-generation networking platform focused on meaningful professional connections using AI-driven matching algorithms.',
              status: 'Explore Product',
              active: true,
            },
            {
              name: 'SkyFit',
              desc: 'Your comprehensive fitness and nutrition companion. Personalized meal plans and workout routines.',
              status: 'Coming Soon',
              active: false,
            },
            {
              name: 'SkyGratitude',
              desc: 'Cultivate a positive mindset with our gratitude journaling app. Simple, daily practices to enhance well-being.',
              status: 'Coming Soon',
              active: false,
            },
          ].map((product, index) => (
            <motion.div
              key={product.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative p-6 bg-gradient-to-br from-gray-50 to-white rounded-2xl border border-gray-200 overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <h3 className="font-heading font-bold text-xl text-gray-900 mb-3">{product.name}</h3>
              <p className="text-gray-600 text-sm mb-6">{product.desc}</p>
              <span
                className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${
                  product.active
                    ? 'bg-orange-500 text-white'
                    : 'bg-gray-100 text-gray-500'
                }`}
              >
                {product.status}
              </span>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Case Studies Section */}
      <Section background="gray">
        <SectionHeading
          title="Case Studies"
          description="Our custom AI solutions address real-world challenges, deliver measurable results, and drive lasting business impact."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {caseStudies.map((study, index) => (
            <motion.div
              key={study.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <CaseStudyCard
                title={study.title}
                description={study.description}
                slug={study.slug}
                category={study.category}
                techStack={study.techStack}
                results={study.results}
              />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Blogs Section */}
      <Section background="white">
        <SectionHeading
          title="Blogs"
          description="Explore insights, ideas, and strategies designed to inform, inspire, and drive business growth."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {recentBlogs.map((blog, index) => (
            <motion.div
              key={blog.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <BlogCard
                title={blog.title}
                excerpt={blog.excerpt}
                slug={blog.slug}
                category={blog.category}
                readTime={blog.readTime}
                date={blog.date}
              />
            </motion.div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button variant="outline" size="lg" asLink to="/blogs">
            View All Posts
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </Section>

      {/* Stats Section */}
      <Section background="dark">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: '15+', label: 'Projects Delivered' },
            { value: '5+', label: 'Industries Served' },
            { value: '30+', label: 'Team Members' },
            { value: '92%', label: 'Happy Clients' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <StatCard value={stat.value} label={stat.label} variant="dark" />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="white">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-orange-500 to-sunset-400 p-8 md:p-12 lg:p-16">
          <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10" />
          <div className="relative z-10 text-center max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              Let's Work Together
            </h2>
            <p className="text-white/90 text-lg mb-8">
              Ready to bring your digital vision to life? Get in touch and let's create something amazing together.
            </p>
            <Button
              variant="secondary"
              size="lg"
              asLink
              to="/contact-us"
              className="bg-white text-orange-500 hover:bg-gray-100"
            >
              Get Started Today
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </Section>
    </>
  );
}
