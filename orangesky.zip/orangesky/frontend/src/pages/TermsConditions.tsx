import { motion } from 'framer-motion';
import Section from '@/components/ui/Section';

export default function TermsConditions() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[30vh] flex items-center bg-gradient-hero overflow-hidden">
        <div className="container-custom relative z-10 pt-32 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl font-heading font-bold text-white mb-4">
                Terms and Conditions
              </h1>
              <p className="text-gray-300">Last Updated: January 27, 2026</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <Section background="white">
        <div className="max-w-4xl mx-auto prose-custom">
          <h2>1. Acceptance of Terms</h2>
          <p>
            By accessing and using the Orange Sky Solutions website and services, you accept and agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use our services.
          </p>

          <h2>2. Services Description</h2>
          <p>
            Orange Sky Solutions provides digital technology services including but not limited to:
          </p>
          <ul>
            <li>MVP Development</li>
            <li>Web Development</li>
            <li>Mobile App Development</li>
            <li>Cloud Engineering</li>
            <li>Data Analytics</li>
            <li>UI/UX Design</li>
            <li>Enterprise AI Solutions</li>
          </ul>

          <h2>3. User Responsibilities</h2>
          <p>When using our services, you agree to:</p>
          <ul>
            <li>Provide accurate and complete information</li>
            <li>Maintain the confidentiality of your account credentials</li>
            <li>Use our services only for lawful purposes</li>
            <li>Not interfere with the proper functioning of our website</li>
            <li>Respect the intellectual property rights of Orange Sky Solutions and third parties</li>
          </ul>

          <h2>4. Intellectual Property</h2>
          <p>
            All content on our website, including text, graphics, logos, images, and software, is the property of Orange Sky Solutions or its content suppliers and is protected by intellectual property laws.
          </p>
          <p>
            For client projects, intellectual property ownership will be defined in the specific project agreement. Generally, upon full payment, clients receive ownership of deliverables as specified in their contract.
          </p>

          <h2>5. Confidentiality</h2>
          <p>
            We maintain strict confidentiality regarding client information and project details. Any confidential information shared with us will be protected and not disclosed to third parties without prior consent, except as required by law.
          </p>

          <h2>6. Payment Terms</h2>
          <p>
            Payment terms will be outlined in individual project proposals or service agreements. Generally:
          </p>
          <ul>
            <li>Payment schedules are agreed upon before project commencement</li>
            <li>Late payments may incur additional charges</li>
            <li>All fees are non-refundable unless otherwise specified</li>
          </ul>

          <h2>7. Limitation of Liability</h2>
          <p>
            Orange Sky Solutions shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of our services. Our total liability shall not exceed the amount paid by you for the specific service in question.
          </p>

          <h2>8. Warranties and Disclaimers</h2>
          <p>
            Our services are provided "as is" without warranties of any kind, either express or implied. We do not warrant that our services will be uninterrupted, error-free, or completely secure.
          </p>

          <h2>9. Indemnification</h2>
          <p>
            You agree to indemnify and hold harmless Orange Sky Solutions, its officers, directors, employees, and agents from any claims, damages, or expenses arising from your use of our services or violation of these terms.
          </p>

          <h2>10. Termination</h2>
          <p>
            We reserve the right to terminate or suspend access to our services immediately, without prior notice, for any reason, including breach of these Terms and Conditions.
          </p>

          <h2>11. Dispute Resolution</h2>
          <p>
            Any disputes arising from these terms or our services shall be resolved through:
          </p>
          <ol>
            <li>Good faith negotiation between the parties</li>
            <li>Mediation by a mutually agreed mediator</li>
            <li>Binding arbitration in accordance with applicable laws</li>
          </ol>

          <h2>12. Governing Law</h2>
          <p>
            These Terms and Conditions shall be governed by and construed in accordance with the laws of the jurisdiction in which Orange Sky Solutions is registered.
          </p>

          <h2>13. Changes to Terms</h2>
          <p>
            We reserve the right to modify these Terms and Conditions at any time. Changes will be effective immediately upon posting to our website. Your continued use of our services after changes constitutes acceptance of the new terms.
          </p>

          <h2>14. Contact Information</h2>
          <p>
            For questions about these Terms and Conditions, please contact us at:
          </p>
          <ul>
            <li>Email: hello@orangeskysolutions.com</li>
            <li>Website: www.orangeskysolutions.com</li>
          </ul>
        </div>
      </Section>
    </>
  );
}
