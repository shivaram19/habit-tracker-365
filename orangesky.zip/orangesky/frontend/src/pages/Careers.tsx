import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Briefcase, Users, Clock, Heart, Zap, Building2, Coffee } from 'lucide-react';
import Button from '@/components/ui/Button';
import Section from '@/components/ui/Section';
import SectionHeading from '@/components/ui/SectionHeading';
import StatCard from '@/components/ui/StatCard';
import JobCard from '@/components/cards/JobCard';
import { jobListings } from '@/data';

const benefits = [
  {
    icon: Zap,
    title: 'Cutting-Edge Projects',
    description: 'Take part in innovative projects for leading global enterprises, leveraging the newest technologies.',
    features: ['AI Integration', 'Cloud-Native Apps', 'Adaptive Design'],
  },
  {
    icon: Users,
    title: 'Career Growth',
    description: 'Advance your career with structured paths, mentorship programs, and opportunities to enhance your skills.',
    features: ['Promotions', 'Workshops', 'Mentorship'],
  },
  {
    icon: Building2,
    title: 'Modern Workspace',
    description: 'Enjoy thoughtfully designed offices that inspire collaboration, creativity, and productivity.',
    features: ['Collaboration Spaces', 'Game Room', 'Free Meals'],
  },
  {
    icon: Heart,
    title: 'Competitive Benefits',
    description: 'Receive top-tier compensation along with a comprehensive benefits package and equity opportunities.',
    features: ['Stock Options', 'Health Insurance', 'Unlimited PTO'],
  },
];

const hiringProcess = [
  { step: 1, title: 'Application Review', duration: '2-3 days', description: 'We carefully review your application and portfolio to ensure alignment with our requirements.' },
  { step: 2, title: 'Initial Screening', duration: '3–4 days', description: 'We schedule an introductory call to understand your background, skills, and goals.' },
  { step: 3, title: 'Technical Assessment', duration: '5–7 days', description: 'You will complete a practical assignment to demonstrate your abilities.' },
  { step: 4, title: 'Panel Interview', duration: '3–5 days', description: 'You will meet with multiple team members for in-depth discussions.' },
  { step: 5, title: 'Final Interview', duration: '2–3 days', description: 'A concluding discussion with leadership to evaluate long-term alignment.' },
  { step: 6, title: 'Offer & Onboarding', duration: '1 week', description: 'If successful, you will receive a formal offer and start onboarding.' },
];

export default function Careers() {
  const [selectedDepartment, setSelectedDepartment] = useState('all');

  const departments = ['all', ...new Set(jobListings.map((job) => job.department))];
  const filteredJobs = selectedDepartment === 'all'
    ? jobListings
    : jobListings.filter((job) => job.department === selectedDepartment);

  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-sky-400/20 rounded-full blur-3xl" />
        </div>

        <div className="container-custom relative z-10 pt-32 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-6">
                Career with Orange Sky Solutions
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
                Join a team of passionate and driven innovators who are dedicated to shaping the future of technology. Work on exciting and cutting-edge projects, collaborate with talented professionals, and make a real impact that truly matters.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button variant="primary" size="lg" asLink to="#openings">
                  View Open Positions
                </Button>
                <Button variant="outline" size="lg" asLink to="#culture">
                  Learn About Our Culture
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <Section background="white">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { value: `${jobListings.length}`, label: 'Open Positions' },
            { value: '30+', label: 'Team Members' },
            { value: '3 yrs', label: 'Average Tenure' },
            { value: '85%', label: 'Employee Growth' },
          ].map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <StatCard value={stat.value} label={stat.label} />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Why Work Here Section */}
      <Section background="gray" id="culture">
        <SectionHeading
          title="Why Top Talent Chooses Us"
          description="Be part of a company that values your growth, supports your development, and provides an inspiring environment where you can do your best work every day."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={benefit.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-6 rounded-2xl border border-gray-200"
            >
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4">
                <benefit.icon className="h-6 w-6 text-orange-500" />
              </div>
              <h3 className="text-xl font-heading font-bold text-gray-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-600 mb-4">{benefit.description}</p>
              <div className="flex flex-wrap gap-2">
                {benefit.features.map((feature) => (
                  <span
                    key={feature}
                    className="px-3 py-1 bg-gray-100 text-gray-600 text-xs rounded-full"
                  >
                    {feature}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Current Openings Section */}
      <Section background="white" id="openings">
        <SectionHeading
          title="Current Openings"
          description="Explore exciting opportunities and find the role that's right for you. Join our team of passionate innovators and help shape the future of technology."
        />

        {/* Department Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {departments.map((dept) => (
            <button
              key={dept}
              onClick={() => setSelectedDepartment(dept)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                selectedDepartment === dept
                  ? 'bg-orange-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {dept === 'all' ? 'All Departments' : dept}
            </button>
          ))}
        </div>

        {/* Job Listings */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredJobs.map((job, index) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
            >
              <JobCard
                title={job.title}
                department={job.department}
                location={job.location}
                type={job.type}
                experience={job.experience}
                slug={job.slug}
                featured={job.featured}
              />
            </motion.div>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">No positions available in this department at the moment.</p>
          </div>
        )}
      </Section>

      {/* Hiring Process Section */}
      <Section background="gray">
        <SectionHeading
          title="How We Hire"
          description="Our clear and transparent hiring process is designed to help you showcase your skills and succeed every step of the way."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {hiringProcess.map((step, index) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-6 rounded-2xl border border-gray-200"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="w-10 h-10 bg-orange-500 text-white rounded-full flex items-center justify-center font-bold">
                  {step.step}
                </div>
                <div>
                  <h3 className="font-heading font-bold text-gray-900">{step.title}</h3>
                  <p className="text-sm text-orange-500">{step.duration}</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="white">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-orange-500 to-sunset-400 p-8 md:p-12 lg:p-16">
          <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10" />
          <div className="relative z-10 text-center max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              Start Your Journey Today
            </h2>
            <p className="text-white/90 text-lg mb-8">
              Don't see the perfect role? We're always looking for exceptional talent. Send us your resume and let's explore opportunities together.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                variant="secondary"
                size="lg"
                asLink
                to="/contact-us"
                className="bg-white text-orange-500 hover:bg-gray-100"
              >
                Submit General Application
              </Button>
              <Button
                variant="outline"
                size="lg"
                asLink
                to="/contact-us"
                className="border-white text-white hover:bg-white/10"
              >
                Schedule a Chat
              </Button>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
