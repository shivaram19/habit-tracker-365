import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, HelpCircle, ChevronRight } from 'lucide-react';
import Section from '@/components/ui/Section';
import SectionHeading from '@/components/ui/SectionHeading';
import Accordion from '@/components/ui/Accordion';
import Input from '@/components/ui/Input';
import Badge from '@/components/ui/Badge';

// Static FAQs data - will be replaced with API call when backend is ready
const staticFAQs = {
  'MVP Development': [
    {
      id: '1',
      question: 'What is an MVP and why do startups need it?',
      answer: 'MVP (Minimum Viable Product) is a minimal version of your product that validates your core idea with real users. It takes 8–12 weeks instead of long development cycles. 73% of MVPs we\'ve built helped startups raise funding successfully.',
    },
    {
      id: '2',
      question: 'What\'s the difference between MVP, Prototype, and Proof of Concept?',
      answer: 'MVP is a working version with backend and database. Prototype is a UI-only clickable demo for visualization. POC (Proof of Concept) is a technical feasibility test to validate if something can be built.',
    },
    {
      id: '3',
      question: 'How long does it take to build an MVP?',
      answer: '8–12 weeks is typical. Rush projects can be done in 6 weeks with focused scope. Complex MVPs may take 14–16 weeks depending on features and integrations required.',
    },
    {
      id: '4',
      question: 'Should I build my MVP with no-code or custom development?',
      answer: 'No-code is fast and simple for basic validation. Custom development is scalable, investor-friendly, and better for complex requirements. We recommend custom for most funded startups.',
    },
    {
      id: '5',
      question: 'What features should I include in my MVP?',
      answer: 'Only core value features that solve the main problem. Avoid extras and nice-to-haves. Focus on the one thing that makes users say "I need this."',
    },
    {
      id: '6',
      question: 'Can I raise funding with an MVP?',
      answer: 'Yes! 67% of seed-stage startups raise funding with MVPs. Investors prefer seeing a working product with real user traction over just a pitch deck.',
    },
    {
      id: '7',
      question: 'What tech stack should I use for my MVP?',
      answer: 'We recommend React/Next.js for web, React Native for mobile, Node.js/Python for backend, PostgreSQL for database, and Vercel/AWS for hosting. This stack is fast, scalable, and developer-friendly.',
    },
    {
      id: '8',
      question: 'Should my MVP work on Web, iOS & Android?',
      answer: 'Start with the platform where your early adopters are. Usually that\'s web (fastest to build) or one mobile platform. Cross-platform comes after validation.',
    },
    {
      id: '9',
      question: 'How do I validate my MVP idea before development?',
      answer: 'User interviews (talk to 20+ potential users), landing pages (measure signup interest), manual services (do things manually first), and competitor analysis (learn from existing solutions).',
    },
    {
      id: '10',
      question: 'What happens after MVP launch — rebuild or iterate?',
      answer: 'Always iterate unless you\'re pivoting completely or the architecture is fundamentally flawed. Building on a solid MVP foundation is faster than starting over.',
    },
    {
      id: '11',
      question: 'Can you build my MVP if I\'m non-technical?',
      answer: 'Yes! 70% of founders we work with are non-technical. We translate your vision into technical requirements and keep you informed at every step.',
    },
    {
      id: '12',
      question: 'What if my MVP fails — is the investment wasted?',
      answer: 'No — MVP prevents deeper waste. Learning that an idea doesn\'t work after 10 weeks saves you from spending 18 months on something nobody wants. Code can often be reused for pivots.',
    },
    {
      id: '13',
      question: 'Do you sign NDAs for MVP projects?',
      answer: 'Yes, we sign NDAs before any detailed discussions. You own 100% of the IP and source code we create for you.',
    },
  ],
  'Web Development': [
    {
      id: '14',
      question: 'What technologies do you use for web development?',
      answer: 'We primarily use React, Next.js, Vue.js, and Angular for frontend. For backend, we work with Node.js, Python (Django/FastAPI), and .NET. Our database expertise includes PostgreSQL, MongoDB, and Redis.',
    },
    {
      id: '15',
      question: 'How long does it take to build a custom web application?',
      answer: 'Simple websites take 4-6 weeks. Medium complexity web apps take 8-12 weeks. Enterprise applications can take 16-24 weeks depending on scope and integrations.',
    },
    {
      id: '16',
      question: 'Do you provide ongoing maintenance and support?',
      answer: 'Yes, we offer flexible maintenance plans including bug fixes, security updates, performance optimization, and feature enhancements on monthly retainers.',
    },
  ],
  'Cloud Engineering': [
    {
      id: '17',
      question: 'Which cloud platforms do you work with?',
      answer: 'We work with AWS, Microsoft Azure, and Google Cloud Platform. We help you choose the right platform based on your requirements, budget, and existing tech stack.',
    },
    {
      id: '18',
      question: 'How much can cloud migration reduce our infrastructure costs?',
      answer: 'Typically 30-50% cost reduction through right-sizing, reserved instances, and eliminating over-provisioned resources. We\'ve helped clients save up to 60% on their cloud bills.',
    },
    {
      id: '19',
      question: 'How long does a cloud migration take?',
      answer: 'Simple lift-and-shift migrations take 4-8 weeks. Re-architecting applications for cloud-native takes 12-20 weeks. Enterprise migrations are phased over 6-12 months.',
    },
  ],
  'Mobile Development': [
    {
      id: '20',
      question: 'Should I build native or cross-platform mobile apps?',
      answer: 'Cross-platform (React Native/Flutter) works for 80% of apps and reduces development time by 40%. Native is better for games, AR/VR, or apps requiring deep device integration.',
    },
    {
      id: '21',
      question: 'React Native vs Flutter — which should I choose?',
      answer: 'React Native if your team knows JavaScript/React. Flutter for pixel-perfect UI and better performance. Both are excellent choices with large ecosystems.',
    },
    {
      id: '22',
      question: 'How long does it take to build a mobile app?',
      answer: 'Simple apps: 8-12 weeks. Medium complexity: 12-16 weeks. Complex apps with multiple integrations: 16-24 weeks. We provide detailed timelines during discovery.',
    },
    {
      id: '22a',
      question: 'How much does it cost to build a mobile app?',
      answer: 'Simple apps start around $30-50K. Medium complexity apps run $50-100K. Enterprise apps with complex integrations can be $100-250K+. We provide detailed quotes after understanding your requirements.',
    },
    {
      id: '22b',
      question: 'Do you build for both iOS and Android?',
      answer: 'Yes! We build for both platforms. With cross-platform frameworks like React Native, we can target both iOS and Android with a single codebase, reducing time and cost by up to 40%.',
    },
    {
      id: '22c',
      question: 'Will you help with App Store and Play Store submission?',
      answer: 'Absolutely. We handle the entire submission process including app store optimization (ASO), screenshots, descriptions, and navigating Apple and Google review guidelines.',
    },
    {
      id: '22d',
      question: 'Can you integrate my app with existing backend systems?',
      answer: 'Yes, we regularly integrate mobile apps with existing APIs, databases, CRMs, payment gateways, and third-party services. We can also build custom APIs if needed.',
    },
    {
      id: '22e',
      question: 'How do you ensure mobile app security?',
      answer: 'We implement secure authentication (OAuth 2.0, biometrics), encrypted data storage, certificate pinning, code obfuscation, and follow OWASP mobile security guidelines.',
    },
    {
      id: '22f',
      question: 'Do you provide app maintenance and updates?',
      answer: 'Yes, we offer ongoing maintenance plans covering bug fixes, OS updates compatibility, performance optimization, and feature enhancements. Most clients choose monthly retainers.',
    },
    {
      id: '22g',
      question: 'Can you add push notifications to my app?',
      answer: 'Yes, we implement push notifications using Firebase Cloud Messaging (FCM) or Apple Push Notification service (APNs). We can set up automated, scheduled, or triggered notifications.',
    },
    {
      id: '22h',
      question: 'What about offline functionality?',
      answer: 'We can build offline-first apps that work without internet connection and sync when connectivity is restored. This is common for field service, healthcare, and productivity apps.',
    },
    {
      id: '22i',
      question: 'How do you handle app testing?',
      answer: 'We use a combination of unit tests, integration tests, and UI automation testing. We also conduct manual QA on real devices and can set up beta testing programs via TestFlight and Google Play Beta.',
    },
    {
      id: '22j',
      question: 'Can you build apps with AR or camera features?',
      answer: 'Yes, we have experience with ARKit (iOS), ARCore (Android), camera integrations, QR/barcode scanning, image recognition, and real-time video features.',
    },
  ],
  'AI & Machine Learning': [
    {
      id: '23',
      question: 'What\'s the difference between AI, ML, and Deep Learning?',
      answer: 'AI is the broad concept of machines performing tasks intelligently. ML is a subset where machines learn from data. Deep Learning uses neural networks for complex pattern recognition.',
    },
    {
      id: '24',
      question: 'Is my business ready for AI implementation?',
      answer: 'You need: clean, structured data (at least 6 months worth), a clear business problem to solve, and stakeholder buy-in. We help assess readiness during our discovery phase.',
    },
    {
      id: '25',
      question: 'What ROI can I expect from AI solutions?',
      answer: 'Depends on use case. Customer service automation typically sees 40-60% cost reduction. Predictive maintenance can reduce downtime by 30-50%. We provide ROI projections specific to your case.',
    },
  ],
  'UI/UX Design': [
    {
      id: '26',
      question: 'What\'s the difference between UI and UX design?',
      answer: 'UX (User Experience) focuses on the overall feel and user journey. UI (User Interface) focuses on visual design — colors, typography, buttons. Both are essential for successful products.',
    },
    {
      id: '27',
      question: 'How long does the design process take?',
      answer: 'Discovery and research: 1-2 weeks. Wireframing: 1-2 weeks. Visual design: 2-3 weeks. Prototyping and testing: 1-2 weeks. Total: 5-9 weeks depending on scope.',
    },
    {
      id: '28',
      question: 'What design tools do you use?',
      answer: 'Figma for UI design and prototyping, FigJam for workshops, Maze for user testing, and various analytics tools for UX research. We deliver in formats your team can use.',
    },
  ],
};

const categories = Object.keys(staticFAQs);

export default function FAQs() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [filteredFAQs, setFilteredFAQs] = useState(staticFAQs);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredFAQs(staticFAQs);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered: typeof staticFAQs = {} as typeof staticFAQs;

    Object.entries(staticFAQs).forEach(([category, faqs]) => {
      const matchingFaqs = faqs.filter(
        (faq) =>
          faq.question.toLowerCase().includes(query) ||
          faq.answer.toLowerCase().includes(query)
      );
      if (matchingFaqs.length > 0) {
        (filtered as any)[category] = matchingFaqs;
      }
    });

    setFilteredFAQs(filtered);
  }, [searchQuery]);

  const totalFAQs = Object.values(filteredFAQs).reduce((sum, faqs) => sum + faqs.length, 0);

  return (
    <>
      {/* Hero Section */}
      <section className="relative bg-gradient-hero text-white py-20 md:py-28">
        <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
        <div className="container-custom relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl mx-auto text-center"
          >
            <Badge variant="orange" className="mb-4">
              Knowledge Base
            </Badge>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold mb-6">
              Frequently Asked{' '}
              <span className="text-gradient-orange">Questions</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-300 mb-8">
              Find answers to common questions about our services, processes, and technologies.
            </p>

            {/* Search Bar */}
            <div className="relative max-w-xl mx-auto">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            {searchQuery && (
              <p className="mt-4 text-gray-400">
                Found {totalFAQs} result{totalFAQs !== 1 ? 's' : ''} for "{searchQuery}"
              </p>
            )}
          </motion.div>
        </div>
      </section>

      {/* Category Navigation */}
      <section className="bg-gray-50 border-b border-gray-200 sticky top-20 z-30">
        <div className="container-custom">
          <div className="flex items-center gap-2 py-4 overflow-x-auto scrollbar-hide">
            <button
              onClick={() => setActiveCategory(null)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeCategory === null
                  ? 'bg-orange-500 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
            >
              All Categories
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                  activeCategory === category
                    ? 'bg-orange-500 text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* FAQs Content */}
      <Section>
        <div className="max-w-4xl mx-auto">
          {Object.entries(filteredFAQs)
            .filter(([category]) => !activeCategory || category === activeCategory)
            .map(([category, faqs], categoryIndex) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: categoryIndex * 0.1 }}
                className="mb-12"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center">
                    <HelpCircle className="w-5 h-5 text-orange-500" />
                  </div>
                  <h2 className="text-2xl font-heading font-bold text-gray-900">
                    {category}
                  </h2>
                  <Badge variant="secondary">{faqs.length} questions</Badge>
                </div>

                <div className="space-y-4">
                  {faqs.map((faq, faqIndex) => (
                    <Accordion
                      key={faq.id}
                      title={faq.question}
                      defaultOpen={faqIndex === 0 && categoryIndex === 0}
                    >
                      <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                    </Accordion>
                  ))}
                </div>
              </motion.div>
            ))}

          {Object.keys(filteredFAQs).length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <HelpCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No FAQs found
              </h3>
              <p className="text-gray-600">
                Try adjusting your search query or browse all categories.
              </p>
            </motion.div>
          )}
        </div>
      </Section>

      {/* Contact CTA */}
      <section className="bg-gradient-hero text-white py-16">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-heading font-bold mb-4">
            Can't find what you're looking for?
          </h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
            Our team is here to help. Reach out and we'll get back to you within 24 hours.
          </p>
          <a
            href="/contact-us"
            className="inline-flex items-center gap-2 btn-primary px-8 py-4 text-lg"
          >
            Contact Us
            <ChevronRight className="w-5 h-5" />
          </a>
        </div>
      </section>
    </>
  );
}
