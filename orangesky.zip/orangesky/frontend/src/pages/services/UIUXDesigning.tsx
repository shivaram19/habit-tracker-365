import { Palette } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const uiuxData: ServiceData = {
  title: 'UI/UX Design Services',
  tagline: 'Design That Delights Users',
  description: 'Create intuitive, beautiful digital experiences that engage users and drive business results.',
  icon: <Palette className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '200+', label: 'Projects Designed' },
    { value: '95%', label: 'Client Satisfaction' },
    { value: '40%', label: 'Conversion Increase' },
    { value: '15+', label: 'Design Awards' },
  ],
  executiveSummary: {
    title: 'User-Centered Design Excellence',
    description: 'We create digital experiences that put users first. Through research, testing, and iterative design, we craft interfaces that are not only beautiful but also intuitive and effective at achieving business goals.',
    points: [
      'Research-driven design decisions',
      'User testing and validation',
      'Accessible and inclusive design',
      'Design system development',
      'Conversion-focused optimization',
    ],
  },
  solutions: [
    {
      title: 'UX Research & Strategy',
      description: 'Understand your users deeply through research to inform design decisions.',
      features: ['User interviews', 'Competitive analysis', 'Journey mapping', 'Persona development'],
    },
    {
      title: 'UI Design',
      description: 'Create visually stunning interfaces that reflect your brand and engage users.',
      features: ['Visual design', 'Interactive prototypes', 'Design systems', 'Responsive design'],
    },
    {
      title: 'Usability Testing',
      description: 'Validate designs with real users to ensure optimal experience.',
      features: ['User testing', 'A/B testing', 'Analytics review', 'Iterative improvements'],
    },
  ],
  process: [
    { step: 1, title: 'Discovery', description: 'Research users, competitors, and business goals.' },
    { step: 2, title: 'Define', description: 'Synthesize findings into clear design requirements.' },
    { step: 3, title: 'Ideate', description: 'Explore solutions through sketches and concepts.' },
    { step: 4, title: 'Design', description: 'Create high-fidelity designs and prototypes.' },
    { step: 5, title: 'Test', description: 'Validate with users and iterate.' },
    { step: 6, title: 'Deliver', description: 'Hand off assets and support development.' },
  ],
  techStack: [
    { category: 'Design Tools', technologies: ['Figma', 'Sketch', 'Adobe XD', 'Framer'] },
    { category: 'Prototyping', technologies: ['Figma', 'Principle', 'ProtoPie', 'InVision'] },
    { category: 'Research', technologies: ['Hotjar', 'UserTesting', 'Maze', 'Optimal Workshop'] },
    { category: 'Development', technologies: ['Storybook', 'Zeplin', 'Tailwind CSS', 'Framer Motion'] },
  ],
  faqs: [
    {
      question: 'What\'s the difference between UI and UX?',
      answer: 'UX (User Experience) focuses on the overall experience and usability, while UI (User Interface) focuses on visual design and interactive elements. Both are essential for great digital products.',
    },
    {
      question: 'Do you conduct user research?',
      answer: 'Yes, user research is central to our design process. We conduct interviews, surveys, usability tests, and analytics analysis to inform design decisions.',
    },
    {
      question: 'Can you redesign our existing product?',
      answer: 'Absolutely. We often help companies redesign existing products, starting with an audit and then implementing improvements based on research.',
    },
    {
      question: 'Do you create design systems?',
      answer: 'Yes, we create comprehensive design systems with reusable components, patterns, and guidelines that ensure consistency across your digital products.',
    },
  ],
  cta: {
    title: 'Elevate Your User Experience',
    description: 'Ready to create digital experiences users love? Let\'s discuss your design needs.',
    primaryButton: { label: 'Start Design Project', href: '/contact-us' },
    secondaryButton: { label: 'View Design Portfolio', href: '/case-studies' },
  },
};

export default function UIUXDesigning() {
  return <ServicePageTemplate data={uiuxData} />;
}
