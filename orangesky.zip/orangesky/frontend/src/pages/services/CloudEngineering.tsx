import { Cloud } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const cloudData: ServiceData = {
  title: 'Cloud Engineering Services',
  tagline: 'Scalable Cloud Infrastructure',
  description: 'Design, build, and manage cloud infrastructure that scales with your business. AWS, Azure, and GCP expertise.',
  icon: <Cloud className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '99.99%', label: 'Uptime SLA' },
    { value: '40%', label: 'Cost Reduction' },
    { value: '100+', label: 'Migrations Done' },
    { value: '24/7', label: 'Monitoring' },
  ],
  executiveSummary: {
    title: 'Enterprise-Grade Cloud Solutions',
    description: 'We help businesses leverage cloud technology to improve agility, reduce costs, and scale efficiently. Our cloud engineers design and implement secure, optimized infrastructure across major cloud platforms.',
    points: [
      'Multi-cloud and hybrid cloud architectures',
      'Infrastructure as Code (IaC) for consistency',
      'Automated scaling and cost optimization',
      'Security-first design with compliance',
      '24/7 monitoring and incident response',
    ],
  },
  solutions: [
    {
      title: 'Cloud Migration',
      description: 'Seamlessly migrate your applications and data to the cloud with minimal disruption.',
      features: ['Assessment & planning', 'Data migration', 'Application modernization', 'Testing & validation'],
    },
    {
      title: 'Cloud Native Development',
      description: 'Build applications designed specifically for cloud environments.',
      features: ['Microservices architecture', 'Containerization', 'Serverless functions', 'Event-driven design'],
    },
    {
      title: 'DevOps & Automation',
      description: 'Streamline development and operations with automated pipelines.',
      features: ['CI/CD pipelines', 'Infrastructure as Code', 'Monitoring & logging', 'Auto-scaling'],
    },
  ],
  process: [
    { step: 1, title: 'Assessment', description: 'Evaluate current infrastructure and define cloud strategy.' },
    { step: 2, title: 'Architecture', description: 'Design scalable, secure cloud architecture.' },
    { step: 3, title: 'Migration', description: 'Execute migration with minimal downtime.' },
    { step: 4, title: 'Optimization', description: 'Fine-tune performance and costs.' },
    { step: 5, title: 'Security', description: 'Implement security controls and compliance.' },
    { step: 6, title: 'Operations', description: 'Ongoing management and optimization.' },
  ],
  techStack: [
    { category: 'AWS', technologies: ['EC2', 'Lambda', 'S3', 'RDS', 'EKS'] },
    { category: 'Azure', technologies: ['VMs', 'Functions', 'Blob Storage', 'AKS'] },
    { category: 'DevOps', technologies: ['Terraform', 'Kubernetes', 'Docker', 'Ansible'] },
    { category: 'Monitoring', technologies: ['Prometheus', 'Grafana', 'CloudWatch', 'Datadog'] },
  ],
  faqs: [
    {
      question: 'Which cloud platform do you recommend?',
      answer: 'It depends on your specific needs. AWS is great for variety, Azure for Microsoft integrations, and GCP for data/ML. We help you choose the best fit.',
    },
    {
      question: 'How do you ensure security in the cloud?',
      answer: 'We implement security at every layer: identity management, network security, encryption, monitoring, and compliance controls specific to your industry.',
    },
    {
      question: 'Can you help reduce our cloud costs?',
      answer: 'Yes, we typically achieve 20-40% cost reduction through right-sizing, reserved instances, spot instances, and architecture optimization.',
    },
    {
      question: 'Do you support multi-cloud strategies?',
      answer: 'Absolutely. We design and implement multi-cloud and hybrid cloud architectures to maximize flexibility and avoid vendor lock-in.',
    },
  ],
  cta: {
    title: 'Modernize Your Infrastructure',
    description: 'Ready to harness the power of the cloud? Let\'s discuss your cloud strategy.',
    primaryButton: { label: 'Get Cloud Assessment', href: '/contact-us' },
    secondaryButton: { label: 'View Case Studies', href: '/case-studies' },
  },
};

export default function CloudEngineering() {
  return <ServicePageTemplate data={cloudData} />;
}
