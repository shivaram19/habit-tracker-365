import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import Button from '@/components/ui/Button';
import Section from '@/components/ui/Section';
import SectionHeading from '@/components/ui/SectionHeading';
import StatCard from '@/components/ui/StatCard';
import Accordion from '@/components/ui/Accordion';
import CaseStudyCard from '@/components/cards/CaseStudyCard';
import { caseStudies } from '@/data';

export interface ServiceData {
  title: string;
  tagline: string;
  description: string;
  icon: ReactNode;
  stats: Array<{ value: string; label: string }>;
  executiveSummary: {
    title: string;
    description: string;
    points: string[];
  };
  solutions: Array<{
    title: string;
    description: string;
    features: string[];
  }>;
  process: Array<{
    step: number;
    title: string;
    description: string;
  }>;
  techStack: Array<{
    category: string;
    technologies: string[];
  }>;
  faqs: Array<{
    question: string;
    answer: string;
  }>;
  cta: {
    title: string;
    description: string;
    primaryButton: { label: string; href: string };
    secondaryButton?: { label: string; href: string };
  };
}

interface ServicePageTemplateProps {
  data: ServiceData;
}

export default function ServicePageTemplate({ data }: ServicePageTemplateProps) {
  const relevantCaseStudies = caseStudies.slice(0, 2);

  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[60vh] flex items-center bg-gradient-hero overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-orange-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/3 right-1/4 w-96 h-96 bg-sky-400/20 rounded-full blur-3xl" />
        </div>

        <div className="container-custom relative z-10 pt-32 pb-16">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-orange-500/20 rounded-2xl mb-6">
                {data.icon}
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-white mb-4">
                {data.title}
              </h1>
              
              <p className="text-xl text-orange-400 mb-4">{data.tagline}</p>
              
              <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
                {data.description}
              </p>

              <div className="flex flex-wrap justify-center gap-4">
                <Button variant="primary" size="lg" asLink to="/contact-us">
                  Get Started
                </Button>
                <Button variant="outline" size="lg" asLink to="#solutions">
                  Explore Solutions
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <Section background="white">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {data.stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <StatCard value={stat.value} label={stat.label} />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Executive Summary */}
      <Section background="gray">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-gray-900 mb-6">
              {data.executiveSummary.title}
            </h2>
            <p className="text-gray-600 mb-8">
              {data.executiveSummary.description}
            </p>
            <ul className="space-y-4">
              {data.executiveSummary.points.map((point, index) => (
                <li key={index} className="flex items-start gap-3">
                  <CheckCircle2 className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{point}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-square bg-gradient-to-br from-orange-100 to-sky-100 rounded-3xl flex items-center justify-center">
              <div className="text-8xl">{data.icon}</div>
            </div>
          </motion.div>
        </div>
      </Section>

      {/* Solutions Section */}
      <Section background="white" id="solutions">
        <SectionHeading
          title="Our Solutions"
          description="Comprehensive solutions tailored to your specific needs and business objectives."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {data.solutions.map((solution, index) => (
            <motion.div
              key={solution.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-all"
            >
              <h3 className="font-heading font-bold text-xl text-gray-900 mb-3">
                {solution.title}
              </h3>
              <p className="text-gray-600 mb-4">{solution.description}</p>
              <ul className="space-y-2">
                {solution.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full" />
                    {feature}
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Process Section */}
      <Section background="gray">
        <SectionHeading
          title="Our Process"
          description="A proven methodology that ensures consistent, high-quality results for every project."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {data.process.map((step, index) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative bg-white rounded-2xl p-6 border border-gray-200"
            >
              <div className="absolute -top-4 left-6 w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                {step.step}
              </div>
              <h3 className="font-heading font-bold text-lg text-gray-900 mt-2 mb-2">
                {step.title}
              </h3>
              <p className="text-gray-600 text-sm">{step.description}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Tech Stack Section */}
      <Section background="white">
        <SectionHeading
          title="Technology Stack"
          description="We leverage cutting-edge technologies to build robust, scalable solutions."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {data.techStack.map((category, index) => (
            <motion.div
              key={category.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-gray-50 rounded-2xl p-6"
            >
              <h3 className="font-heading font-bold text-gray-900 mb-4">
                {category.category}
              </h3>
              <div className="flex flex-wrap gap-2">
                {category.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1 bg-white border border-gray-200 text-gray-600 text-sm rounded-full"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Case Studies Section */}
      <Section background="gray">
        <SectionHeading
          title="Related Case Studies"
          description="See how we've helped businesses achieve their goals with our solutions."
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {relevantCaseStudies.map((study, index) => (
            <motion.div
              key={study.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <CaseStudyCard
                title={study.title}
                description={study.description}
                slug={study.slug}
                category={study.category}
                techStack={study.techStack}
                results={study.results}
              />
            </motion.div>
          ))}
        </div>
      </Section>

      {/* FAQ Section */}
      <Section background="white">
        <SectionHeading
          title="Frequently Asked Questions"
          description="Find answers to common questions about our services."
        />

        <div className="max-w-3xl mx-auto">
          <Accordion
            items={data.faqs.map((faq, index) => ({
              id: `faq-${index}`,
              title: faq.question,
              content: faq.answer,
            }))}
          />
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="white">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-orange-500 to-sunset-400 p-8 md:p-12 lg:p-16">
          <div className="absolute inset-0 bg-[url('/pattern.svg')] opacity-10" />
          <div className="relative z-10 text-center max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
              {data.cta.title}
            </h2>
            <p className="text-white/90 text-lg mb-8">
              {data.cta.description}
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                variant="secondary"
                size="lg"
                asLink
                to={data.cta.primaryButton.href}
                className="bg-white text-orange-500 hover:bg-gray-100"
              >
                {data.cta.primaryButton.label}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              {data.cta.secondaryButton && (
                <Button
                  variant="outline"
                  size="lg"
                  asLink
                  to={data.cta.secondaryButton.href}
                  className="border-white text-white hover:bg-white/10"
                >
                  {data.cta.secondaryButton.label}
                </Button>
              )}
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
