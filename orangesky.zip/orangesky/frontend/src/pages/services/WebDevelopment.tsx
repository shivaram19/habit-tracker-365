import { Globe } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const webDevData: ServiceData = {
  title: 'Web Development Services',
  tagline: 'Custom Web Solutions That Scale',
  description: 'Build powerful, responsive web applications with cutting-edge technologies. From landing pages to enterprise platforms.',
  icon: <Globe className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '150+', label: 'Websites Delivered' },
    { value: '99.9%', label: 'Uptime Guarantee' },
    { value: '3x', label: 'Performance Boost' },
    { value: '50+', label: 'Happy Clients' },
  ],
  executiveSummary: {
    title: 'Web Applications That Drive Business Growth',
    description: 'We create custom web solutions that combine stunning design with powerful functionality. Our development approach focuses on performance, security, and scalability to ensure your web presence drives real business results.',
    points: [
      'Custom web applications tailored to your needs',
      'Mobile-first, responsive design approach',
      'SEO optimization for maximum visibility',
      'Performance optimization for fast load times',
      'Secure, scalable architecture',
    ],
  },
  solutions: [
    {
      title: 'Corporate Websites',
      description: 'Professional, conversion-focused websites that represent your brand and drive business goals.',
      features: ['Custom design', 'CMS integration', 'Lead generation', 'Analytics setup'],
    },
    {
      title: 'E-Commerce Platforms',
      description: 'Scalable online stores with seamless payment processing and inventory management.',
      features: ['Product catalogs', 'Payment gateways', 'Inventory management', 'Order tracking'],
    },
    {
      title: 'Web Applications',
      description: 'Complex web applications with rich functionality and exceptional user experience.',
      features: ['Real-time features', 'User dashboards', 'API integrations', 'Data visualization'],
    },
  ],
  process: [
    { step: 1, title: 'Requirements', description: 'Detailed analysis of your business goals and technical requirements.' },
    { step: 2, title: 'Design', description: 'UI/UX design with wireframes, mockups, and interactive prototypes.' },
    { step: 3, title: 'Development', description: 'Clean, maintainable code with modern frameworks and best practices.' },
    { step: 4, title: 'Testing', description: 'Cross-browser, cross-device testing and performance optimization.' },
    { step: 5, title: 'Deployment', description: 'Secure deployment with CI/CD pipelines and monitoring.' },
    { step: 6, title: 'Maintenance', description: 'Ongoing support, updates, and continuous improvement.' },
  ],
  techStack: [
    { category: 'Frontend', technologies: ['React', 'Next.js', 'Vue.js', 'TypeScript', 'Tailwind CSS'] },
    { category: 'Backend', technologies: ['Node.js', 'Python', 'Django', 'Express', 'GraphQL'] },
    { category: 'Database', technologies: ['PostgreSQL', 'MongoDB', 'Redis', 'Prisma'] },
    { category: 'DevOps', technologies: ['AWS', 'Vercel', 'Docker', 'GitHub Actions'] },
  ],
  faqs: [
    {
      question: 'What technologies do you use?',
      answer: 'We primarily use React/Next.js for frontend and Node.js/Python for backend, but we select the best technology stack based on your specific project requirements.',
    },
    {
      question: 'How long does a typical web project take?',
      answer: 'Simple websites take 4-6 weeks, while complex web applications may take 3-6 months. We provide detailed timelines during the planning phase.',
    },
    {
      question: 'Do you provide ongoing maintenance?',
      answer: 'Yes, we offer various maintenance packages including security updates, performance monitoring, feature additions, and 24/7 support.',
    },
    {
      question: 'Is the website SEO-friendly?',
      answer: 'Absolutely. All our websites are built with SEO best practices, including semantic HTML, fast load times, and proper meta tags.',
    },
  ],
  cta: {
    title: 'Let\'s Build Your Web Presence',
    description: 'Transform your digital presence with a custom web solution. Contact us for a free consultation.',
    primaryButton: { label: 'Start Your Project', href: '/contact-us' },
    secondaryButton: { label: 'View Portfolio', href: '/case-studies' },
  },
};

export default function WebDevelopment() {
  return <ServicePageTemplate data={webDevData} />;
}
