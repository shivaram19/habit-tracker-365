import { BarChart3 } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const dataAnalyticsData: ServiceData = {
  title: 'Data Analytics Services',
  tagline: 'Turn Data Into Decisions',
  description: 'Unlock actionable insights from your data with advanced analytics, business intelligence, and AI-powered reporting.',
  icon: <BarChart3 className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '10B+', label: 'Data Points Processed' },
    { value: '85%', label: 'Faster Insights' },
    { value: '50+', label: 'Analytics Projects' },
    { value: '3x', label: 'ROI Average' },
  ],
  executiveSummary: {
    title: 'Data-Driven Decision Making',
    description: 'We help organizations harness the power of their data through modern analytics solutions. From data warehousing to predictive analytics, we build systems that turn raw data into competitive advantage.',
    points: [
      'End-to-end data pipeline development',
      'Real-time analytics dashboards',
      'Predictive modeling and forecasting',
      'Custom reporting and visualization',
      'Data governance and quality assurance',
    ],
  },
  solutions: [
    {
      title: 'Business Intelligence',
      description: 'Interactive dashboards and reports that provide real-time visibility into business performance.',
      features: ['KPI dashboards', 'Automated reporting', 'Data visualization', 'Self-service analytics'],
    },
    {
      title: 'Data Engineering',
      description: 'Build robust data infrastructure that collects, transforms, and stores data efficiently.',
      features: ['ETL pipelines', 'Data warehousing', 'Data lakes', 'Real-time streaming'],
    },
    {
      title: 'Predictive Analytics',
      description: 'Leverage machine learning to forecast trends and make data-driven predictions.',
      features: ['Demand forecasting', 'Churn prediction', 'Anomaly detection', 'Recommendation systems'],
    },
  ],
  process: [
    { step: 1, title: 'Discovery', description: 'Understand your data landscape and business objectives.' },
    { step: 2, title: 'Data Audit', description: 'Assess data quality, sources, and integration points.' },
    { step: 3, title: 'Architecture', description: 'Design scalable data infrastructure.' },
    { step: 4, title: 'Implementation', description: 'Build pipelines, models, and dashboards.' },
    { step: 5, title: 'Training', description: 'Enable your team with tools and knowledge.' },
    { step: 6, title: 'Optimization', description: 'Continuous improvement and model refinement.' },
  ],
  techStack: [
    { category: 'Data Processing', technologies: ['Apache Spark', 'Airflow', 'dbt', 'Kafka'] },
    { category: 'Databases', technologies: ['Snowflake', 'BigQuery', 'Redshift', 'PostgreSQL'] },
    { category: 'Visualization', technologies: ['Tableau', 'Power BI', 'Looker', 'Metabase'] },
    { category: 'ML/AI', technologies: ['Python', 'TensorFlow', 'scikit-learn', 'MLflow'] },
  ],
  faqs: [
    {
      question: 'What data sources can you integrate?',
      answer: 'We can integrate virtually any data source including databases, APIs, CRMs, ERPs, cloud services, spreadsheets, and custom applications.',
    },
    {
      question: 'How long does it take to see results?',
      answer: 'Initial dashboards can be delivered in 2-4 weeks. Full analytics platforms typically take 2-4 months depending on complexity.',
    },
    {
      question: 'Do you provide training for our team?',
      answer: 'Yes, we provide comprehensive training on all tools and dashboards, plus documentation and ongoing support.',
    },
    {
      question: 'How do you ensure data security?',
      answer: 'We implement role-based access control, encryption at rest and in transit, audit logging, and comply with relevant regulations like GDPR.',
    },
  ],
  cta: {
    title: 'Unlock Your Data\'s Potential',
    description: 'Transform your data into actionable insights. Let\'s discuss your analytics needs.',
    primaryButton: { label: 'Get Data Assessment', href: '/contact-us' },
    secondaryButton: { label: 'View Case Studies', href: '/case-studies' },
  },
};

export default function DataAnalytics() {
  return <ServicePageTemplate data={dataAnalyticsData} />;
}
