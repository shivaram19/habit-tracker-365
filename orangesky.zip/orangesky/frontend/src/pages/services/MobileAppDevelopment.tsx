import { Smartphone } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const mobileData: ServiceData = {
  title: 'Mobile App Development',
  tagline: 'Native & Cross-Platform Apps',
  description: 'Create stunning mobile experiences for iOS and Android with native performance and beautiful design.',
  icon: <Smartphone className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '100+', label: 'Apps Launched' },
    { value: '4.8★', label: 'Average Rating' },
    { value: '10M+', label: 'App Downloads' },
    { value: '50+', label: 'Happy Clients' },
  ],
  executiveSummary: {
    title: 'Mobile Apps That Users Love',
    description: 'We design and develop mobile applications that deliver exceptional user experiences. Whether you need a consumer app, enterprise solution, or companion app for your web platform, we have the expertise to bring your vision to life.',
    points: [
      'Native iOS and Android development',
      'Cross-platform solutions with React Native',
      'User-centric design and UX research',
      'App Store optimization and launch support',
      'Ongoing maintenance and updates',
    ],
  },
  solutions: [
    {
      title: 'Native Development',
      description: 'High-performance apps built specifically for iOS or Android platforms.',
      features: ['Swift/Kotlin development', 'Platform-specific features', 'Maximum performance', 'OS integration'],
    },
    {
      title: 'Cross-Platform Apps',
      description: 'Cost-effective apps that work seamlessly on both iOS and Android.',
      features: ['React Native/Flutter', 'Shared codebase', 'Native performance', 'Faster development'],
    },
    {
      title: 'Enterprise Mobile',
      description: 'Secure mobile solutions for enterprise workforce and operations.',
      features: ['MDM integration', 'Enterprise SSO', 'Offline functionality', 'Secure data handling'],
    },
  ],
  process: [
    { step: 1, title: 'Strategy', description: 'Define app goals, target users, and platform strategy.' },
    { step: 2, title: 'Design', description: 'Create intuitive UI/UX with platform-specific patterns.' },
    { step: 3, title: 'Development', description: 'Build with clean architecture and best practices.' },
    { step: 4, title: 'Testing', description: 'Device testing, performance, and security validation.' },
    { step: 5, title: 'Launch', description: 'App store submission and launch optimization.' },
    { step: 6, title: 'Growth', description: 'Post-launch updates, analytics, and optimization.' },
  ],
  techStack: [
    { category: 'iOS', technologies: ['Swift', 'SwiftUI', 'Objective-C', 'Xcode'] },
    { category: 'Android', technologies: ['Kotlin', 'Jetpack Compose', 'Java', 'Android Studio'] },
    { category: 'Cross-Platform', technologies: ['React Native', 'Flutter', 'Expo'] },
    { category: 'Backend', technologies: ['Node.js', 'Firebase', 'AWS Amplify', 'GraphQL'] },
  ],
  faqs: [
    {
      question: 'Should I build native or cross-platform?',
      answer: 'It depends on your needs. Native offers best performance and platform features; cross-platform reduces cost and development time. We help you choose based on your specific requirements.',
    },
    {
      question: 'How long does app development take?',
      answer: 'Simple apps take 2-3 months, medium complexity 4-6 months, and complex apps 6-12 months. We provide detailed timelines during planning.',
    },
    {
      question: 'Do you handle App Store submissions?',
      answer: 'Yes, we manage the entire submission process for both Apple App Store and Google Play Store, including handling reviews and updates.',
    },
    {
      question: 'Can you update our existing app?',
      answer: 'Absolutely. We take over and modernize existing apps, fixing issues, adding features, and improving performance.',
    },
  ],
  cta: {
    title: 'Build Your Mobile App',
    description: 'Ready to reach users on their mobile devices? Let\'s discuss your app idea.',
    primaryButton: { label: 'Start Your App', href: '/contact-us' },
    secondaryButton: { label: 'View App Portfolio', href: '/case-studies' },
  },
};

export default function MobileAppDevelopment() {
  return <ServicePageTemplate data={mobileData} />;
}
