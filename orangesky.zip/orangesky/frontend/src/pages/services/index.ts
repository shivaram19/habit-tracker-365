export { default as MVPDevelopment } from './MVPDevelopment';
export { default as WebDevelopment } from './WebDevelopment';
export { default as CloudEngineering } from './CloudEngineering';
export { default as DataAnalytics } from './DataAnalytics';
export { default as MobileAppDevelopment } from './MobileAppDevelopment';
export { default as UIUXDesigning } from './UIUXDesigning';
export { default as EnterpriseAISolutions } from './EnterpriseAISolutions';
