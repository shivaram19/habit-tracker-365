import { Brain } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const aiData: ServiceData = {
  title: 'Enterprise AI Solutions',
  tagline: 'AI-Powered Business Transformation',
  description: 'Leverage cutting-edge artificial intelligence to automate processes, gain insights, and create competitive advantage.',
  icon: <Brain className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '50+', label: 'AI Projects Delivered' },
    { value: '70%', label: 'Process Automation' },
    { value: '10x', label: 'Efficiency Gains' },
    { value: '$100M+', label: 'Client Value Created' },
  ],
  executiveSummary: {
    title: 'AI That Drives Real Business Value',
    description: 'We help enterprises harness the power of AI to transform operations, enhance customer experiences, and unlock new opportunities. From strategy to implementation, we guide you through every step of your AI journey.',
    points: [
      'Custom AI/ML model development',
      'Large Language Model (LLM) integration',
      'Intelligent process automation',
      'AI-powered analytics and insights',
      'Responsible AI and governance',
    ],
  },
  solutions: [
    {
      title: 'Conversational AI',
      description: 'Build intelligent chatbots and virtual assistants that understand and engage users naturally.',
      features: ['GPT-4 integration', 'Custom fine-tuning', 'Multi-channel deployment', 'Context awareness'],
    },
    {
      title: 'AI Process Automation',
      description: 'Automate complex business processes with intelligent decision-making.',
      features: ['Document processing', 'Workflow automation', 'Decision engines', 'Exception handling'],
    },
    {
      title: 'Predictive AI',
      description: 'Leverage machine learning to forecast, predict, and optimize business outcomes.',
      features: ['Demand forecasting', 'Risk assessment', 'Anomaly detection', 'Recommendation systems'],
    },
  ],
  process: [
    { step: 1, title: 'AI Assessment', description: 'Evaluate AI readiness and identify high-impact opportunities.' },
    { step: 2, title: 'Use Case Design', description: 'Define specific AI use cases with clear ROI.' },
    { step: 3, title: 'Data Preparation', description: 'Collect, clean, and prepare data for AI models.' },
    { step: 4, title: 'Model Development', description: 'Build and train custom AI models.' },
    { step: 5, title: 'Integration', description: 'Deploy AI into production systems.' },
    { step: 6, title: 'Optimization', description: 'Monitor, retrain, and improve continuously.' },
  ],
  techStack: [
    { category: 'LLMs', technologies: ['OpenAI GPT-4', 'Claude', 'LLaMA', 'Mistral'] },
    { category: 'ML Frameworks', technologies: ['TensorFlow', 'PyTorch', 'scikit-learn', 'XGBoost'] },
    { category: 'AI Infrastructure', technologies: ['LangChain', 'Pinecone', 'Weaviate', 'MLflow'] },
    { category: 'Cloud AI', technologies: ['AWS SageMaker', 'Azure AI', 'Google Vertex AI', 'Hugging Face'] },
  ],
  faqs: [
    {
      question: 'How do I know if AI is right for my business?',
      answer: 'We start with an AI assessment to identify where AI can add value. Good candidates include processes with high volume, clear patterns, and where small improvements have big impact.',
    },
    {
      question: 'What about data privacy and security?',
      answer: 'We implement strict data governance, including encryption, access controls, and compliance with regulations. We can deploy models on-premises or in private clouds when required.',
    },
    {
      question: 'How long does an AI project take?',
      answer: 'Simple AI integrations can be done in 4-8 weeks. Custom ML models typically take 3-6 months. Complex enterprise AI platforms may take 6-12 months.',
    },
    {
      question: 'Can you work with our existing AI initiatives?',
      answer: 'Absolutely. We often join existing initiatives to accelerate progress, optimize models, or help with production deployment.',
    },
  ],
  cta: {
    title: 'Start Your AI Journey',
    description: 'Ready to transform your business with AI? Let\'s explore the possibilities together.',
    primaryButton: { label: 'Book AI Assessment', href: '/contact-us' },
    secondaryButton: { label: 'View AI Case Studies', href: '/case-studies' },
  },
};

export default function EnterpriseAISolutions() {
  return <ServicePageTemplate data={aiData} />;
}
