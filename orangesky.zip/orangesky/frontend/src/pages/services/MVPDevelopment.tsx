import { Rocket } from 'lucide-react';
import ServicePageTemplate, { ServiceData } from './ServicePageTemplate';

const mvpData: ServiceData = {
  title: 'MVP Development Services',
  tagline: 'From Idea to Market in Weeks',
  description: 'Launch faster with AI-powered MVPs. We help startups and enterprises validate ideas quickly with lean, scalable solutions.',
  icon: <Rocket className="h-8 w-8 text-orange-500" />,
  stats: [
    { value: '70+', label: 'MVPs Launched' },
    { value: '60%', label: 'Faster Time-to-Market' },
    { value: '85%', label: 'Funding Success Rate' },
    { value: '24/7', label: 'Support Available' },
  ],
  executiveSummary: {
    title: 'Transform Ideas into Market-Ready Products',
    description: 'We specialize in rapidly developing Minimum Viable Products that help you test market assumptions, gather user feedback, and iterate quickly. Our AI-enhanced development process reduces time-to-market while maintaining quality.',
    points: [
      'Rapid prototyping with AI-assisted development',
      'User-centric design validated through testing',
      'Scalable architecture for future growth',
      'Continuous iteration based on market feedback',
      'Full technical documentation and handoff',
    ],
  },
  solutions: [
    {
      title: 'Startup MVP',
      description: 'Launch your startup idea with a focused, feature-complete MVP that validates your core hypothesis.',
      features: ['Core feature development', 'User authentication', 'Basic analytics', 'Mobile-responsive design'],
    },
    {
      title: 'Enterprise Prototype',
      description: 'Test new product concepts within your organization with secure, enterprise-grade prototypes.',
      features: ['Enterprise SSO', 'Compliance ready', 'Internal testing tools', 'Executive dashboards'],
    },
    {
      title: 'AI-Powered MVP',
      description: 'Incorporate AI capabilities from day one with our specialized AI MVP development service.',
      features: ['AI/ML integration', 'Smart automation', 'Predictive features', 'Natural language processing'],
    },
  ],
  process: [
    { step: 1, title: 'Discovery', description: 'Deep dive into your vision, market, and target users to define the MVP scope.' },
    { step: 2, title: 'Design Sprint', description: 'Rapid prototyping and user testing to validate design decisions.' },
    { step: 3, title: 'Development', description: 'Agile development with weekly demos and continuous feedback.' },
    { step: 4, title: 'Testing', description: 'Comprehensive QA to ensure a bug-free launch experience.' },
    { step: 5, title: 'Launch', description: 'Deployment to production with monitoring and support.' },
    { step: 6, title: 'Iterate', description: 'Post-launch optimization based on real user data.' },
  ],
  techStack: [
    { category: 'Frontend', technologies: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS'] },
    { category: 'Backend', technologies: ['Node.js', 'Python', 'PostgreSQL', 'Redis'] },
    { category: 'Cloud', technologies: ['AWS', 'Azure', 'Vercel', 'Docker'] },
    { category: 'AI/ML', technologies: ['OpenAI', 'LangChain', 'TensorFlow', 'PyTorch'] },
  ],
  faqs: [
    {
      question: 'How long does it take to build an MVP?',
      answer: 'Typically 6-12 weeks depending on complexity. Our AI-powered development process can reduce this by up to 40% compared to traditional methods.',
    },
    {
      question: 'What is included in the MVP package?',
      answer: 'Our MVP package includes discovery workshops, UI/UX design, full-stack development, testing, deployment, and 30 days of post-launch support.',
    },
    {
      question: 'Can the MVP scale after launch?',
      answer: 'Absolutely. We build MVPs with scalability in mind, using modern architecture patterns that can grow with your user base.',
    },
    {
      question: 'Do you help with investor pitches?',
      answer: 'Yes, we can prepare technical documentation, architecture diagrams, and demo environments specifically designed for investor presentations.',
    },
  ],
  cta: {
    title: 'Ready to Build Your MVP?',
    description: 'Let\'s turn your idea into a market-ready product. Book a free strategy call today.',
    primaryButton: { label: 'Book Strategy Call', href: '/contact-us' },
    secondaryButton: { label: 'View Case Studies', href: '/case-studies' },
  },
};

export default function MVPDevelopment() {
  return <ServicePageTemplate data={mvpData} />;
}
