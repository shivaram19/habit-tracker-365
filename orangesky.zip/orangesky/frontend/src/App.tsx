import { Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import AdminLayout from './components/layout/AdminLayout';

// Import all pages
import {
  // Marketing Pages
  Home,
  Industries,
  Careers,
  ContactUs,
  Blogs,
  BlogPost,
  FAQs,
  PrivacyPolicy,
  TermsConditions,
  NotFound,
  // Service Pages
  MVPDevelopment,
  WebDevelopment,
  CloudEngineering,
  DataAnalytics,
  MobileAppDevelopment,
  UIUXDesigning,
  EnterpriseAISolutions,
  // Admin Pages
  AdminDashboard,
  AdminLogin,
  AdminBlogs,
  AdminCareers,
  AdminFAQs,
} from './pages';

function App() {
  return (
    <Routes>
      {/* Marketing Routes */}
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="industries" element={<Industries />} />
        <Route path="careers" element={<Careers />} />
        <Route path="contact-us" element={<ContactUs />} />
        <Route path="blogs" element={<Blogs />} />
        <Route path="blogs/:slug" element={<BlogPost />} />
        <Route path="faqs" element={<FAQs />} />
        <Route path="privacy-policy" element={<PrivacyPolicy />} />
        <Route path="terms-conditions" element={<TermsConditions />} />

        {/* Service Routes */}
        <Route path="mvp-development" element={<MVPDevelopment />} />
        <Route path="web-development" element={<WebDevelopment />} />
        <Route path="cloud-engineering" element={<CloudEngineering />} />
        <Route path="data-analytics" element={<DataAnalytics />} />
        <Route path="mobile-app-development" element={<MobileAppDevelopment />} />
        <Route path="ui-ux-designing" element={<UIUXDesigning />} />
        <Route path="enterprise-ai-solutions" element={<EnterpriseAISolutions />} />
      </Route>

      {/* Admin Routes */}
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<AdminLayout />}>
        <Route index element={<AdminDashboard />} />
        <Route path="blogs" element={<AdminBlogs />} />
        <Route path="careers" element={<AdminCareers />} />
        <Route path="faqs" element={<AdminFAQs />} />
      </Route>

      {/* 404 */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

export default App;
