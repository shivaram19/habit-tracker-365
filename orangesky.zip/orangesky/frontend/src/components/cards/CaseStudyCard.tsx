import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import Badge from '../ui/Badge';

export interface CaseStudyCardProps {
  title: string;
  description: string;
  slug: string;
  category: string;
  image?: string;
  techStack: string[];
  results?: { label: string; value: string }[];
  className?: string;
}

/**
 * Case study card component
 */
export default function CaseStudyCard({
  title,
  description,
  slug,
  category,
  image,
  techStack,
  results,
  className,
}: CaseStudyCardProps) {
  return (
    <div
      className={cn(
        'group bg-white rounded-2xl overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-lg',
        className
      )}
    >
      {/* Image */}
      <div className="relative aspect-video overflow-hidden bg-gray-100">
        {image ? (
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-500 to-sky-400">
            <span className="text-6xl">🚀</span>
          </div>
        )}
        <div className="absolute top-4 left-4">
          <Badge variant="orange">{category}</Badge>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {/* Title */}
        <h3 className="text-xl font-heading font-bold text-gray-900 mb-3">
          {title}
        </h3>

        {/* Description */}
        <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">
          {description}
        </p>

        {/* Tech Stack */}
        <div className="flex flex-wrap gap-2 mb-4">
          {techStack.map((tech) => (
            <span
              key={tech}
              className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-lg"
            >
              {tech}
            </span>
          ))}
        </div>

        {/* Results */}
        {results && results.length > 0 && (
          <div className="grid grid-cols-3 gap-2 mb-4 p-3 bg-gray-50 rounded-xl">
            {results.slice(0, 3).map((result, index) => (
              <div key={index} className="text-center">
                <p className="text-lg font-bold text-orange-500">{result.value}</p>
                <p className="text-xs text-gray-500">{result.label}</p>
              </div>
            ))}
          </div>
        )}

        {/* Link */}
        <Link
          to={`/case-studies/${slug}`}
          className="flex items-center text-sm font-medium text-orange-500 hover:text-orange-600 transition-colors"
        >
          <span>View Case Study</span>
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Link>
      </div>
    </div>
  );
}
