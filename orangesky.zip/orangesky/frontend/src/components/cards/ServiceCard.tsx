import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface ServiceCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  href: string;
  className?: string;
  variant?: 'default' | 'featured';
}

/**
 * Service card component for displaying services
 */
export default function ServiceCard({
  title,
  description,
  icon,
  href,
  className,
  variant = 'default',
}: ServiceCardProps) {
  return (
    <Link
      to={href}
      className={cn(
        'group block p-6 rounded-2xl transition-all duration-300',
        variant === 'default'
          ? 'bg-white border border-gray-200 hover:border-orange-200 hover:shadow-lg hover:-translate-y-1'
          : 'bg-gradient-to-br from-orange-500 to-sunset-400 text-white shadow-lg hover:shadow-xl hover:-translate-y-1',
        className
      )}
    >
      {/* Icon */}
      <div
        className={cn(
          'w-14 h-14 rounded-xl flex items-center justify-center mb-5',
          variant === 'default'
            ? 'bg-orange-100 text-orange-500 group-hover:bg-orange-500 group-hover:text-white'
            : 'bg-white/20 text-white'
        )}
      >
        {icon}
      </div>

      {/* Content */}
      <h3
        className={cn(
          'text-xl font-heading font-bold mb-3',
          variant === 'default' ? 'text-gray-900' : 'text-white'
        )}
      >
        {title}
      </h3>
      <p
        className={cn(
          'text-sm leading-relaxed mb-4',
          variant === 'default' ? 'text-gray-600' : 'text-white/90'
        )}
      >
        {description}
      </p>

      {/* Link */}
      <div
        className={cn(
          'flex items-center text-sm font-medium',
          variant === 'default'
            ? 'text-orange-500 group-hover:text-orange-600'
            : 'text-white'
        )}
      >
        <span>Learn More</span>
        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}
