import { Link } from 'react-router-dom';
import { ArrowRight, Clock } from 'lucide-react';
import { cn, formatDate } from '@/lib/utils';
import Badge from '../ui/Badge';

export interface BlogCardProps {
  title: string;
  excerpt: string;
  slug: string;
  category: string;
  readTime: number;
  date: string;
  image?: string;
  className?: string;
  featured?: boolean;
}

/**
 * Blog card component for displaying blog posts
 */
export default function BlogCard({
  title,
  excerpt,
  slug,
  category,
  readTime,
  date,
  image,
  className,
  featured = false,
}: BlogCardProps) {
  return (
    <Link
      to={`/blogs/${slug}`}
      className={cn(
        'group block bg-white rounded-2xl overflow-hidden border border-gray-200 transition-all duration-300 hover:shadow-lg hover:-translate-y-1',
        featured && 'lg:flex',
        className
      )}
    >
      {/* Image */}
      <div
        className={cn(
          'relative overflow-hidden bg-gray-100',
          featured ? 'lg:w-1/2 aspect-video lg:aspect-auto' : 'aspect-video'
        )}
      >
        {image ? (
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-orange-100 to-sky-100">
            <span className="text-4xl">📝</span>
          </div>
        )}
        <div className="absolute top-4 left-4">
          <Badge variant="orange">{category}</Badge>
        </div>
      </div>

      {/* Content */}
      <div className={cn('p-6', featured && 'lg:w-1/2 lg:flex lg:flex-col lg:justify-center')}>
        {/* Meta */}
        <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
          <span>{formatDate(date)}</span>
          <span className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            {readTime} min read
          </span>
        </div>

        {/* Title */}
        <h3 className="text-xl font-heading font-bold text-gray-900 mb-3 group-hover:text-orange-500 transition-colors line-clamp-2">
          {title}
        </h3>

        {/* Excerpt */}
        <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">
          {excerpt}
        </p>

        {/* Link */}
        <div className="flex items-center text-sm font-medium text-orange-500 group-hover:text-orange-600">
          <span>Read More</span>
          <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
        </div>
      </div>
    </Link>
  );
}
