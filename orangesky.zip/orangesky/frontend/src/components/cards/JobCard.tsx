import { Link } from 'react-router-dom';
import { ArrowRight, MapPin, Clock, Briefcase } from 'lucide-react';
import { cn } from '@/lib/utils';
import Badge from '../ui/Badge';

export interface JobCardProps {
  title: string;
  department: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Contract' | 'Remote';
  experience: string;
  slug: string;
  className?: string;
  featured?: boolean;
}

/**
 * Job listing card component
 */
export default function JobCard({
  title,
  department,
  location,
  type,
  experience,
  slug,
  className,
  featured = false,
}: JobCardProps) {
  return (
    <Link
      to={`/careers/${slug}`}
      className={cn(
        'group block p-6 rounded-2xl border transition-all duration-300 hover:shadow-lg hover:-translate-y-1',
        featured
          ? 'bg-gradient-to-br from-orange-500 to-sunset-400 text-white border-transparent'
          : 'bg-white border-gray-200 hover:border-orange-200',
        className
      )}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3
            className={cn(
              'text-lg font-heading font-bold mb-1',
              featured ? 'text-white' : 'text-gray-900'
            )}
          >
            {title}
          </h3>
          <p className={cn('text-sm', featured ? 'text-white/80' : 'text-gray-500')}>
            {department}
          </p>
        </div>
        <Badge variant={featured ? 'gray' : 'orange'} size="sm">
          {type}
        </Badge>
      </div>

      {/* Details */}
      <div className="space-y-2 mb-4">
        <div
          className={cn(
            'flex items-center gap-2 text-sm',
            featured ? 'text-white/80' : 'text-gray-600'
          )}
        >
          <MapPin className="h-4 w-4" />
          <span>{location}</span>
        </div>
        <div
          className={cn(
            'flex items-center gap-2 text-sm',
            featured ? 'text-white/80' : 'text-gray-600'
          )}
        >
          <Briefcase className="h-4 w-4" />
          <span>{experience}</span>
        </div>
      </div>

      {/* Link */}
      <div
        className={cn(
          'flex items-center text-sm font-medium',
          featured ? 'text-white' : 'text-orange-500 group-hover:text-orange-600'
        )}
      >
        <span>View Details</span>
        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
      </div>
    </Link>
  );
}
