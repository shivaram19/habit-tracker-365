import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import { Mail } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { api } from '@/lib/api';

// Validation schema
const newsletterSchema = z.object({
  email: z.string().email('Please enter a valid email'),
});

type NewsletterFormData = z.infer<typeof newsletterSchema>;

export interface NewsletterFormProps {
  className?: string;
  variant?: 'light' | 'dark';
}

/**
 * Newsletter subscription form
 */
export default function NewsletterForm({ className, variant = 'light' }: NewsletterFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<NewsletterFormData>({
    resolver: zodResolver(newsletterSchema),
  });

  const onSubmit = async (data: NewsletterFormData) => {
    setIsSubmitting(true);
    try {
      await api.post('/newsletter', data);
      toast.success('Successfully subscribed to our newsletter!');
      reset();
    } catch (error) {
      toast.error('Failed to subscribe. Please try again.');
      console.error('Newsletter form error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={className}>
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex-1">
          <Input
            type="email"
            placeholder="Enter your email"
            error={errors.email?.message}
            leftIcon={<Mail className="h-5 w-5" />}
            className={variant === 'dark' ? 'bg-gray-800 border-gray-700 text-white' : ''}
            {...register('email')}
          />
        </div>
        <Button
          type="submit"
          variant="primary"
          size="lg"
          isLoading={isSubmitting}
        >
          Subscribe
        </Button>
      </div>
    </form>
  );
}
