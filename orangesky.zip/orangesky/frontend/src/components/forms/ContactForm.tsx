import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import toast from 'react-hot-toast';
import { Send } from 'lucide-react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Textarea from '../ui/Textarea';
import Select from '../ui/Select';
import { api } from '@/lib/api';

// Validation schema
const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email'),
  phone: z.string().optional(),
  company: z.string().optional(),
  service: z.string().optional(),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

type ContactFormData = z.infer<typeof contactSchema>;

const serviceOptions = [
  { value: 'mvp-development', label: 'MVP Development' },
  { value: 'web-development', label: 'Web Development' },
  { value: 'mobile-app-development', label: 'Mobile App Development' },
  { value: 'cloud-engineering', label: 'Cloud Engineering' },
  { value: 'data-analytics', label: 'Data Analytics' },
  { value: 'ui-ux-designing', label: 'UI/UX Designing' },
  { value: 'enterprise-ai-solutions', label: 'Enterprise AI Solutions' },
  { value: 'other', label: 'Other' },
];

export interface ContactFormProps {
  className?: string;
}

/**
 * Contact form component with validation
 */
export default function ContactForm({ className }: ContactFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    try {
      await api.post('/contact', data);
      toast.success('Message sent successfully! We\'ll get back to you soon.');
      reset();
    } catch (error) {
      toast.error('Failed to send message. Please try again.');
      console.error('Contact form error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className={className}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Input
          label="Full Name"
          placeholder="John Doe"
          error={errors.name?.message}
          required
          {...register('name')}
        />
        <Input
          label="Email Address"
          type="email"
          placeholder="john@example.com"
          error={errors.email?.message}
          required
          {...register('email')}
        />
        <Input
          label="Phone Number"
          type="tel"
          placeholder="+1 (555) 000-0000"
          error={errors.phone?.message}
          {...register('phone')}
        />
        <Input
          label="Company"
          placeholder="Your Company"
          error={errors.company?.message}
          {...register('company')}
        />
      </div>

      <div className="mb-6">
        <Select
          label="Service Interest"
          options={serviceOptions}
          placeholder="Select a service"
          error={errors.service?.message}
          {...register('service')}
        />
      </div>

      <div className="mb-6">
        <Textarea
          label="Message"
          placeholder="Tell us about your project..."
          rows={5}
          error={errors.message?.message}
          required
          {...register('message')}
        />
      </div>

      <Button
        type="submit"
        variant="primary"
        size="lg"
        isLoading={isSubmitting}
        rightIcon={<Send className="h-4 w-4" />}
        className="w-full md:w-auto"
      >
        Send Message
      </Button>
    </form>
  );
}
