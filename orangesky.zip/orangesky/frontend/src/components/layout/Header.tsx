import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import Button from '../ui/Button';

// Navigation configuration
const navigation = {
  services: [
    { name: 'MVP Development', href: '/mvp-development', description: 'Launch your MVP in 8-12 weeks' },
    { name: 'Web Development', href: '/web-development', description: 'Enterprise-grade web applications' },
    { name: 'Mobile App Development', href: '/mobile-app-development', description: 'iOS & Android apps' },
    { name: 'Cloud Engineering', href: '/cloud-engineering', description: 'AWS, Azure & GCP solutions' },
    { name: 'Data Analytics', href: '/data-analytics', description: 'Turn data into decisions' },
    { name: 'UI/UX Designing', href: '/ui-ux-designing', description: 'User-centered design' },
    { name: 'Enterprise AI Solutions', href: '/enterprise-ai-solutions', description: 'AI-powered automation' },
  ],
  company: [
    { name: 'About Us', href: '/about' },
    { name: 'Careers', href: '/careers' },
    { name: 'Contact Us', href: '/contact-us' },
  ],
  resources: [
    { name: 'Blogs', href: '/blogs' },
    { name: 'FAQs', href: '/faqs' },
    { name: 'Case Studies', href: '/case-studies' },
  ],
};

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
    setActiveDropdown(null);
  }, [location]);

  const toggleDropdown = (name: string) => {
    setActiveDropdown(activeDropdown === name ? null : name);
  };

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-soft'
          : 'bg-transparent'
      )}
    >
      <nav className="container-custom">
        <div className="flex h-20 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-sunset-400 flex items-center justify-center">
                <span className="text-white font-bold text-xl">O</span>
              </div>
              <div className="ml-2">
                <span className={cn(
                  'font-heading font-bold text-xl',
                  scrolled ? 'text-gray-900' : 'text-white'
                )}>
                  Orange Sky
                </span>
                <span className={cn(
                  'font-heading font-bold text-xl ml-1',
                  scrolled ? 'text-orange-500' : 'text-orange-400'
                )}>
                  Solutions
                </span>
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex lg:items-center lg:gap-x-8">
            {/* Services Dropdown */}
            <div className="relative">
              <button
                onClick={() => toggleDropdown('services')}
                className={cn(
                  'flex items-center gap-x-1 text-sm font-medium transition-colors',
                  scrolled ? 'text-gray-700 hover:text-orange-500' : 'text-white/90 hover:text-white'
                )}
              >
                Services
                <ChevronDown
                  className={cn(
                    'h-4 w-4 transition-transform',
                    activeDropdown === 'services' && 'rotate-180'
                  )}
                />
              </button>

              {activeDropdown === 'services' && (
                <div className="absolute left-0 top-full mt-3 w-80 origin-top-left rounded-2xl bg-white p-4 shadow-xl ring-1 ring-gray-900/5">
                  <div className="space-y-1">
                    {navigation.services.map((item) => (
                      <Link
                        key={item.name}
                        to={item.href}
                        className="block rounded-xl p-3 hover:bg-gray-50 transition-colors"
                      >
                        <p className="font-medium text-gray-900">{item.name}</p>
                        <p className="mt-1 text-sm text-gray-500">{item.description}</p>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Industries */}
            <NavLink
              to="/industries"
              className={({ isActive }) =>
                cn(
                  'text-sm font-medium transition-colors',
                  isActive
                    ? 'text-orange-500'
                    : scrolled
                    ? 'text-gray-700 hover:text-orange-500'
                    : 'text-white/90 hover:text-white'
                )
              }
            >
              Industries
            </NavLink>

            {/* Company Dropdown */}
            <div className="relative">
              <button
                onClick={() => toggleDropdown('company')}
                className={cn(
                  'flex items-center gap-x-1 text-sm font-medium transition-colors',
                  scrolled ? 'text-gray-700 hover:text-orange-500' : 'text-white/90 hover:text-white'
                )}
              >
                Company
                <ChevronDown
                  className={cn(
                    'h-4 w-4 transition-transform',
                    activeDropdown === 'company' && 'rotate-180'
                  )}
                />
              </button>

              {activeDropdown === 'company' && (
                <div className="absolute left-0 top-full mt-3 w-48 origin-top-left rounded-2xl bg-white p-2 shadow-xl ring-1 ring-gray-900/5">
                  {navigation.company.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="block rounded-xl px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-orange-500 transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* Resources Dropdown */}
            <div className="relative">
              <button
                onClick={() => toggleDropdown('resources')}
                className={cn(
                  'flex items-center gap-x-1 text-sm font-medium transition-colors',
                  scrolled ? 'text-gray-700 hover:text-orange-500' : 'text-white/90 hover:text-white'
                )}
              >
                Resources
                <ChevronDown
                  className={cn(
                    'h-4 w-4 transition-transform',
                    activeDropdown === 'resources' && 'rotate-180'
                  )}
                />
              </button>

              {activeDropdown === 'resources' && (
                <div className="absolute left-0 top-full mt-3 w-48 origin-top-left rounded-2xl bg-white p-2 shadow-xl ring-1 ring-gray-900/5">
                  {navigation.resources.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="block rounded-xl px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 hover:text-orange-500 transition-colors"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {/* Careers */}
            <NavLink
              to="/careers"
              className={({ isActive }) =>
                cn(
                  'text-sm font-medium transition-colors',
                  isActive
                    ? 'text-orange-500'
                    : scrolled
                    ? 'text-gray-700 hover:text-orange-500'
                    : 'text-white/90 hover:text-white'
                )
              }
            >
              Careers
            </NavLink>
          </div>

          {/* CTA Buttons */}
          <div className="hidden lg:flex lg:items-center lg:gap-x-4">
            <Button variant="primary" size="md" asLink to="/contact-us">
              Get Started
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            type="button"
            className="lg:hidden rounded-lg p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <span className="sr-only">Toggle menu</span>
            {mobileMenuOpen ? (
              <X className={cn('h-6 w-6', scrolled ? 'text-gray-900' : 'text-white')} />
            ) : (
              <Menu className={cn('h-6 w-6', scrolled ? 'text-gray-900' : 'text-white')} />
            )}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden">
          <div className="fixed inset-0 top-20 z-50 bg-white">
            <div className="overflow-y-auto h-full px-6 py-6 pb-20">
              {/* Services */}
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
                  Services
                </h3>
                <div className="space-y-2">
                  {navigation.services.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="block py-2 text-base font-medium text-gray-900 hover:text-orange-500"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Other Links */}
              <div className="mb-6">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
                  Company
                </h3>
                <div className="space-y-2">
                  <Link to="/industries" className="block py-2 text-base font-medium text-gray-900 hover:text-orange-500">
                    Industries
                  </Link>
                  {navigation.company.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="block py-2 text-base font-medium text-gray-900 hover:text-orange-500"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* Resources */}
              <div className="mb-8">
                <h3 className="text-sm font-semibold text-gray-400 uppercase tracking-wider mb-3">
                  Resources
                </h3>
                <div className="space-y-2">
                  {navigation.resources.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      className="block py-2 text-base font-medium text-gray-900 hover:text-orange-500"
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <div className="pt-6 border-t border-gray-200">
                <Button variant="primary" size="lg" className="w-full" asLink to="/contact-us">
                  Get Started
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Click outside to close dropdown */}
      {activeDropdown && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setActiveDropdown(null)}
        />
      )}
    </header>
  );
}
