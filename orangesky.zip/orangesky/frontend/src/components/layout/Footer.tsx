import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Linkedin, Twitter, Github, Instagram } from 'lucide-react';

const services = [
  { name: 'MVP Development', href: '/mvp-development' },
  { name: 'Web Development', href: '/web-development' },
  { name: 'Mobile App Development', href: '/mobile-app-development' },
  { name: 'Cloud Engineering', href: '/cloud-engineering' },
  { name: 'Data Analytics', href: '/data-analytics' },
  { name: 'UI/UX Designing', href: '/ui-ux-designing' },
  { name: 'Enterprise AI Solutions', href: '/enterprise-ai-solutions' },
];

const quickLinks = [
  { name: 'Contact Us', href: '/contact-us' },
  { name: 'Careers', href: '/careers' },
  { name: 'Blogs', href: '/blogs' },
  { name: 'Privacy Policy', href: '/privacy-policy' },
  { name: 'Terms and Conditions', href: '/terms-conditions' },
];

const socialLinks = [
  { name: 'LinkedIn', href: 'https://linkedin.com/company/orange-sky-solutions', icon: Linkedin },
  { name: 'Twitter', href: 'https://twitter.com/OrangeSkyTech', icon: Twitter },
  { name: 'GitHub', href: 'https://github.com/orange-sky-solutions', icon: Github },
  { name: 'Instagram', href: 'https://instagram.com/orangeskysolutions', icon: Instagram },
];

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer */}
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-sunset-400 flex items-center justify-center">
                <span className="text-white font-bold text-xl">O</span>
              </div>
              <div>
                <span className="font-heading font-bold text-xl text-white">Orange Sky</span>
                <span className="font-heading font-bold text-xl text-orange-400 ml-1">Solutions</span>
              </div>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Elevate Your Digital Vision with Orange Sky Solutions: Where Innovation Meets Excellence
            </p>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-orange-500 hover:text-white transition-all duration-200"
                  aria-label={item.name}
                >
                  <item.icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-heading font-semibold text-lg mb-6">Quick Links</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-400 hover:text-orange-400 transition-colors text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="font-heading font-semibold text-lg mb-6">Our Services</h3>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service.name}>
                  <Link
                    to={service.href}
                    className="text-gray-400 hover:text-orange-400 transition-colors text-sm"
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-heading font-semibold text-lg mb-6">Contact Us</h3>
            
            {/* United States */}
            <div className="mb-6">
              <h4 className="text-orange-400 text-sm font-medium mb-3">United States</h4>
              <ul className="space-y-3">
                <li className="flex items-start gap-3 text-gray-400 text-sm">
                  <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>+1 (XXX) XXX-XXXX</span>
                </li>
                <li className="flex items-start gap-3 text-gray-400 text-sm">
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>Your US Location</span>
                </li>
              </ul>
            </div>

            {/* India */}
            <div className="mb-6">
              <h4 className="text-orange-400 text-sm font-medium mb-3">India</h4>
              <ul className="space-y-3">
                <li className="flex items-start gap-3 text-gray-400 text-sm">
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>Your India Location</span>
                </li>
              </ul>
            </div>

            {/* Email */}
            <div className="flex items-start gap-3 text-gray-400 text-sm">
              <Mail className="h-4 w-4 mt-0.5 flex-shrink-0" />
              <a href="mailto:hello@orangeskysolutions.com" className="hover:text-orange-400 transition-colors">
                hello@orangeskysolutions.com
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="container-custom py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              © {currentYear} Orange Sky Solutions Pvt. Ltd. All Rights Reserved.
            </p>
            <div className="flex items-center gap-6">
              <Link to="/privacy-policy" className="text-gray-500 hover:text-gray-400 text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms-conditions" className="text-gray-500 hover:text-gray-400 text-sm transition-colors">
                Terms & Conditions
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
