import { cn } from '@/lib/utils';

export interface SectionHeadingProps {
  title: string;
  subtitle?: string;
  description?: string;
  centered?: boolean;
  className?: string;
  titleClassName?: string;
  badge?: string;
}

/**
 * Section heading component with title, subtitle, and description
 */
export default function SectionHeading({
  title,
  subtitle,
  description,
  centered = true,
  className,
  titleClassName,
  badge,
}: SectionHeadingProps) {
  return (
    <div className={cn(centered && 'text-center', 'mb-12 lg:mb-16', className)}>
      {badge && (
        <span className="inline-block px-4 py-1.5 mb-4 text-sm font-medium text-orange-500 bg-orange-100 rounded-full">
          {badge}
        </span>
      )}
      {subtitle && (
        <p className="text-orange-500 font-medium mb-3 tracking-wide uppercase text-sm">
          {subtitle}
        </p>
      )}
      <h2
        className={cn(
          'text-3xl md:text-4xl lg:text-5xl font-heading font-bold text-gray-900',
          titleClassName
        )}
      >
        {title}
      </h2>
      {description && (
        <p
          className={cn(
            'mt-4 text-lg text-gray-600 max-w-3xl',
            centered && 'mx-auto'
          )}
        >
          {description}
        </p>
      )}
    </div>
  );
}
