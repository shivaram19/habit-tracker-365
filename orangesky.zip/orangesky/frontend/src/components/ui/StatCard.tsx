import { cn } from '@/lib/utils';

export interface StatCardProps {
  value: string;
  label: string;
  className?: string;
  variant?: 'light' | 'dark';
}

/**
 * Statistics card component
 */
export default function StatCard({
  value,
  label,
  className,
  variant = 'light',
}: StatCardProps) {
  return (
    <div
      className={cn(
        'text-center p-6 rounded-2xl',
        variant === 'light'
          ? 'bg-white shadow-soft border border-gray-100'
          : 'bg-gray-800/50 backdrop-blur border border-gray-700',
        className
      )}
    >
      <p
        className={cn(
          'text-3xl md:text-4xl font-heading font-bold',
          variant === 'light' ? 'text-orange-500' : 'text-orange-400'
        )}
      >
        {value}
      </p>
      <p
        className={cn(
          'mt-2 text-sm font-medium',
          variant === 'light' ? 'text-gray-600' : 'text-gray-400'
        )}
      >
        {label}
      </p>
    </div>
  );
}
