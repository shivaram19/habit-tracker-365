import { cn } from '@/lib/utils';

export interface SectionProps {
  children: React.ReactNode;
  className?: string;
  background?: 'white' | 'gray' | 'dark' | 'gradient';
  id?: string;
}

const backgroundStyles = {
  white: 'bg-white',
  gray: 'bg-gray-50',
  dark: 'bg-gray-900 text-white',
  gradient: 'bg-gradient-hero',
};

/**
 * Section wrapper component for consistent page layout
 */
export default function Section({
  children,
  className,
  background = 'white',
  id,
}: SectionProps) {
  return (
    <section
      id={id}
      className={cn(
        'section-padding',
        backgroundStyles[background],
        className
      )}
    >
      <div className="container-custom">{children}</div>
    </section>
  );
}
