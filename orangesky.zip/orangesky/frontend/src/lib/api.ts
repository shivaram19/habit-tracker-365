import axios from 'axios';

// Create Axios instance with base configuration
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Get token from localStorage if it exists
    const token = localStorage.getItem('adminToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle common errors
    if (error.response) {
      switch (error.response.status) {
        case 401:
          // Unauthorized - redirect to login
          localStorage.removeItem('adminToken');
          if (window.location.pathname.startsWith('/admin')) {
            window.location.href = '/admin/login';
          }
          break;
        case 403:
          // Forbidden
          console.error('Access forbidden');
          break;
        case 404:
          // Not found
          console.error('Resource not found');
          break;
        case 500:
          // Server error
          console.error('Server error');
          break;
        default:
          break;
      }
    }
    return Promise.reject(error);
  }
);

// API helper functions
export const apiHelpers = {
  // GET request
  get: <T>(url: string, params?: Record<string, unknown>) =>
    api.get<T>(url, { params }).then((res) => res.data),

  // POST request
  post: <T>(url: string, data?: unknown) =>
    api.post<T>(url, data).then((res) => res.data),

  // PUT request
  put: <T>(url: string, data?: unknown) =>
    api.put<T>(url, data).then((res) => res.data),

  // PATCH request
  patch: <T>(url: string, data?: unknown) =>
    api.patch<T>(url, data).then((res) => res.data),

  // DELETE request
  delete: <T>(url: string) =>
    api.delete<T>(url).then((res) => res.data),
};

export default api;
