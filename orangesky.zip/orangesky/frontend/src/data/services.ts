import {
  Rocket,
  Globe,
  Cloud,
  BarChart3,
  Smartphone,
  Palette,
  Brain,
} from 'lucide-react';

export interface Service {
  id: string;
  title: string;
  shortDescription: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  features: string[];
  stats: { value: string; label: string }[];
}

export const services: Service[] = [
  {
    id: 'mvp-development',
    title: 'AI MVP Development',
    shortDescription: 'We build AI-powered MVPs in 8–12 weeks for startups and enterprises exploring new markets.',
    description: 'We build AI-powered MVPs in 8–12 weeks for startups and enterprises exploring new markets. Our lean approach delivers cost-effective, production-ready solutions that validate ideas quickly, attract early users, and secure funding.',
    icon: Rocket,
    href: '/mvp-development',
    features: ['Custom MVP Development Strategy', 'Proven Expertise with Successful MVPs', 'Advanced Tools and Frameworks', 'Startup-Focused and Investor-Ready'],
    stats: [
      { value: '4x', label: 'Faster to Market' },
      { value: '70%', label: 'Cost Reduction' },
      { value: '5+', label: 'MVPs Delivered' },
      { value: '92%', label: 'Happy Clients' },
    ],
  },
  {
    id: 'web-development',
    title: 'Website Development',
    shortDescription: 'We build enterprise-grade web portals with modern frameworks and cloud infrastructure.',
    description: 'We build enterprise-grade web portals with modern frameworks and cloud infrastructure. From self-service platforms to dashboards and workflow systems, we create responsive, high-performance web applications.',
    icon: Globe,
    href: '/web-development',
    features: ['React/Next.js', 'Node.js Backend', 'Database Architecture', 'API Integration'],
    stats: [
      { value: '15+', label: 'Projects Built' },
      { value: '2M+', label: 'Lines of Code' },
      { value: '92%', label: 'Happy Clients' },
      { value: '3+', label: 'Years Experience' },
    ],
  },
  {
    id: 'cloud-engineering',
    title: 'Cloud Engineering',
    shortDescription: 'We provide end-to-end cloud migrations, architecture design, and optimization on AWS, Azure, and GCP.',
    description: 'We provide end-to-end cloud migrations, architecture design, and optimization on AWS, Azure, and GCP, minimizing downtime, enhancing security, automated deployments through CI/CD pipelines, and reducing infrastructure costs.',
    icon: Cloud,
    href: '/cloud-engineering',
    features: ['Cloud Infrastructure Architecture', 'CI/CD Solutions', 'Cloud Consulting Services', 'Operational Monitoring'],
    stats: [
      { value: '80%', label: 'Success Rate' },
      { value: '8-12', label: 'Weeks Timeline' },
      { value: '40%', label: 'Cost Reduction' },
      { value: '92%', label: 'Happy Clients' },
    ],
  },
  {
    id: 'data-analytics',
    title: 'Data Analytics',
    shortDescription: 'We design end-to-end data analytics solutions, from data pipelines and warehouse architecture to dashboards.',
    description: 'We design end-to-end data analytics solutions, from data pipelines and warehouse architecture to dashboards and AI-powered forecasting. Our scalable infrastructure processes large datasets and uncovers actionable insights.',
    icon: BarChart3,
    href: '/data-analytics',
    features: ['Business Intelligence', 'Advanced Analytics', 'Customer Analytics', 'Predictive Analytics'],
    stats: [
      { value: '3x', label: 'Decision Speed' },
      { value: '20-40%', label: 'Forecasting Accuracy' },
      { value: '70%', label: 'Reporting Time Reduced' },
      { value: '10-100+', label: 'Users Enabled' },
    ],
  },
  {
    id: 'mobile-app-development',
    title: 'Mobile App Development',
    shortDescription: 'We specialize in custom mobile app development, delivering high-quality cross-platform apps for iOS and Android.',
    description: 'We specialize in custom mobile app development, delivering high-quality cross-platform apps for iOS and Android that streamline workflows, enhance user experience, and drive business growth.',
    icon: Smartphone,
    href: '/mobile-app-development',
    features: ['AI Implementation', 'Intuitive Navigation', 'Real-Time Updates', 'Smart Notifications'],
    stats: [
      { value: '15+', label: 'Projects Built' },
      { value: '2M+', label: 'Lines of Code' },
      { value: '92%', label: 'Happy Clients' },
      { value: '3+', label: 'Years Experience' },
    ],
  },
  {
    id: 'ui-ux-designing',
    title: 'UI/UX Designing',
    shortDescription: 'We create user-centered designs that combine aesthetics with intuitive functionality.',
    description: 'We create user-centered designs that combine aesthetics with intuitive functionality. Through user research, wireframing, prototyping, and usability testing, we craft interfaces that enhance engagement and improve conversions.',
    icon: Palette,
    href: '/ui-ux-designing',
    features: ['User Research & Personas', 'Information Architecture', 'Wireframing & Prototyping', 'UX Strategy'],
    stats: [
      { value: '25%', label: 'Conversion Increase' },
      { value: '30%', label: 'Fewer Errors' },
      { value: '50%', label: 'Faster Prototyping' },
      { value: '40%', label: 'Less Dev Rework' },
    ],
  },
  {
    id: 'enterprise-ai-solutions',
    title: 'Enterprise AI Solutions',
    shortDescription: 'Transform your business with AI-powered strategies made for your goals.',
    description: 'Transform your business with AI-powered strategies made for your goals. At Orange Sky Solutions, we create smart solutions that improve efficiency, support better decisions, and drive lasting growth.',
    icon: Brain,
    href: '/enterprise-ai-solutions',
    features: ['Machine Learning Models', 'Natural Language Processing', 'Computer Vision Systems', 'Generative AI Solutions'],
    stats: [
      { value: '50%', label: 'Faster Deployment' },
      { value: '20-40%', label: 'Cost Reduction' },
      { value: '15-30%', label: 'Decision Accuracy' },
      { value: '10-25%', label: 'Productivity Increase' },
    ],
  },
];

export const getServiceBySlug = (slug: string): Service | undefined => {
  return services.find((service) => service.id === slug);
};
