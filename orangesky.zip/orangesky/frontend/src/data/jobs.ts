export interface JobListing {
  id: string;
  title: string;
  slug: string;
  department: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Contract' | 'Remote';
  experience: string;
  description: string;
  responsibilities: string[];
  requirements: string[];
  benefits: string[];
  featured?: boolean;
}

export const jobListings: JobListing[] = [
  {
    id: '1',
    title: 'Senior Full Stack Developer',
    slug: 'senior-full-stack-developer',
    department: 'Engineering',
    location: 'Remote / India',
    type: 'Full-time',
    experience: '5+ years',
    description: 'We are looking for a Senior Full Stack Developer to join our engineering team and help build cutting-edge web applications for our clients.',
    responsibilities: [
      'Design, develop, and maintain web applications using React, Node.js, and related technologies',
      'Collaborate with product managers and designers to deliver exceptional user experiences',
      'Mentor junior developers and conduct code reviews',
      'Participate in architectural decisions and technical planning',
      'Ensure code quality through testing and best practices',
    ],
    requirements: [
      '5+ years of experience in full-stack development',
      'Strong proficiency in React, Node.js, and TypeScript',
      'Experience with databases (PostgreSQL, MongoDB)',
      'Familiarity with cloud platforms (AWS, GCP, or Azure)',
      'Excellent problem-solving and communication skills',
    ],
    benefits: [
      'Competitive salary and equity options',
      'Remote-first work environment',
      'Health insurance coverage',
      'Learning and development budget',
      'Flexible working hours',
    ],
    featured: true,
  },
  {
    id: '2',
    title: 'AI/ML Engineer',
    slug: 'ai-ml-engineer',
    department: 'AI & Data',
    location: 'Remote / India',
    type: 'Full-time',
    experience: '3+ years',
    description: 'Join our AI team to build intelligent solutions that transform how businesses operate.',
    responsibilities: [
      'Develop and deploy machine learning models for production',
      'Work with large datasets to train and optimize models',
      'Collaborate with engineering teams to integrate AI solutions',
      'Stay updated with the latest AI/ML research and technologies',
      'Document and present technical findings to stakeholders',
    ],
    requirements: [
      '3+ years of experience in ML/AI development',
      'Strong Python skills and familiarity with TensorFlow/PyTorch',
      'Experience with NLP, computer vision, or predictive analytics',
      'Understanding of MLOps and model deployment',
      "Master's or PhD in Computer Science, Statistics, or related field (preferred)",
    ],
    benefits: [
      'Competitive compensation',
      'Work on cutting-edge AI projects',
      'Conference and learning budget',
      'Health and wellness benefits',
      'Stock options',
    ],
    featured: true,
  },
  {
    id: '3',
    title: 'UI/UX Designer',
    slug: 'ui-ux-designer',
    department: 'Design',
    location: 'Remote / India',
    type: 'Full-time',
    experience: '2+ years',
    description: 'We are seeking a creative UI/UX Designer to craft beautiful and intuitive user experiences.',
    responsibilities: [
      'Create wireframes, prototypes, and high-fidelity designs',
      'Conduct user research and usability testing',
      'Collaborate with developers to ensure design implementation',
      'Maintain and evolve design systems',
      'Present design concepts to clients and stakeholders',
    ],
    requirements: [
      '2+ years of UI/UX design experience',
      'Proficiency in Figma and design tools',
      'Strong portfolio demonstrating design thinking',
      'Understanding of web and mobile design patterns',
      'Excellent communication and presentation skills',
    ],
    benefits: [
      'Creative and collaborative environment',
      'Latest design tools and resources',
      'Professional development opportunities',
      'Flexible work arrangements',
      'Comprehensive benefits package',
    ],
  },
  {
    id: '4',
    title: 'DevOps Engineer',
    slug: 'devops-engineer',
    department: 'Engineering',
    location: 'Remote',
    type: 'Full-time',
    experience: '3+ years',
    description: 'Help us build and maintain robust cloud infrastructure and CI/CD pipelines.',
    responsibilities: [
      'Design and maintain cloud infrastructure on AWS/GCP/Azure',
      'Implement and optimize CI/CD pipelines',
      'Monitor system performance and ensure reliability',
      'Automate infrastructure provisioning and deployment',
      'Collaborate with development teams on best practices',
    ],
    requirements: [
      '3+ years of DevOps/SRE experience',
      'Strong knowledge of AWS, Docker, and Kubernetes',
      'Experience with infrastructure as code (Terraform, Pulumi)',
      'Proficiency in scripting (Python, Bash)',
      'Understanding of security best practices',
    ],
    benefits: [
      'Work with modern cloud technologies',
      'Remote-first culture',
      'Competitive salary',
      'Learning and certification budget',
      'Health benefits',
    ],
  },
  {
    id: '5',
    title: 'Product Manager',
    slug: 'product-manager',
    department: 'Product',
    location: 'Remote / US / India',
    type: 'Full-time',
    experience: '4+ years',
    description: 'Lead product strategy and execution for our client projects and internal products.',
    responsibilities: [
      'Define product vision, strategy, and roadmap',
      'Gather and prioritize product requirements',
      'Work closely with engineering, design, and stakeholders',
      'Analyze market trends and competitor products',
      'Measure and optimize product performance',
    ],
    requirements: [
      '4+ years of product management experience',
      'Experience with B2B SaaS or enterprise products',
      'Strong analytical and problem-solving skills',
      'Excellent communication and leadership abilities',
      'Technical background or understanding (preferred)',
    ],
    benefits: [
      'Lead impactful products',
      'Collaborative team environment',
      'Equity participation',
      'Professional development',
      'Comprehensive benefits',
    ],
  },
];

export const getJobBySlug = (slug: string): JobListing | undefined => {
  return jobListings.find((job) => job.slug === slug);
};

export const getFeaturedJobs = (): JobListing[] => {
  return jobListings.filter((job) => job.featured);
};

export const getJobsByDepartment = (department: string): JobListing[] => {
  return jobListings.filter((job) => job.department === department);
};
