export interface CaseStudy {
  id: string;
  title: string;
  slug: string;
  category: string;
  description: string;
  fullDescription: string;
  techStack: string[];
  results: { label: string; value: string }[];
  image?: string;
}

export const caseStudies: CaseStudy[] = [
  {
    id: '1',
    title: 'TalentBridge: An AI-Powered Recruitment Platform',
    slug: 'talentbridge-ai-recruitment-platform',
    category: 'Recruitment',
    description: 'TalentBridge is a custom AI-powered recruitment platform built by Orange Sky Solutions to transform the hiring experience for businesses and job seekers.',
    fullDescription: `TalentBridge is a custom AI-powered recruitment platform built by Orange Sky Solutions to transform the hiring experience for businesses and job seekers. Designed as a next-generation solution, TalentBridge bridges the gap between precision hiring and candidate engagement on a single digital platform.

In today's competitive market, where traditional job portals lack personalization, efficiency, and transparency, TalentBridge introduces features like AI-driven chatbots, skill & culture-fit matching, direct recruiter–candidate messaging, and real-time feedback.

By streamlining the recruitment process, TalentBridge enables companies to find the right talent more quickly while ensuring candidates enjoy a clearer and smarter hiring experience.`,
    techStack: ['MongoDB', 'Express', 'React', 'Node.js'],
    results: [
      { label: 'Time to Hire', value: '-60%' },
      { label: 'Candidate Quality', value: '+85%' },
      { label: 'User Satisfaction', value: '95%' },
    ],
  },
  {
    id: '2',
    title: 'MediCareAI: An AI-Platform for Healthcare Excellence',
    slug: 'medicareai-healthcare-platform',
    category: 'Healthcare',
    description: 'MediCareAI is an AI-based healthcare platform dedicated to optimizing patient health outcomes through AI-generated summaries and clinical decision support.',
    fullDescription: `MediCareAI is an AI-based healthcare platform dedicated to optimizing patient health outcomes, with its aim of AI-generated summaries, clinical decision support, the latest research insights for medical teams, and interactive learning tools.

Beyond just information, it provides interactive learning tools designed to enhance skills, streamline workflows, and empower healthcare professionals to make faster, more informed decisions.

MediCareAI is driven by a vision to redefine healthcare, bridging technology, research, and clinical expertise. By providing actionable, evidence-based insights in real time, it ensures that medical teams are always equipped to deliver the highest quality care.`,
    techStack: ['React', 'Next.js', 'Tailwind CSS', 'JavaScript'],
    results: [
      { label: 'Diagnosis Speed', value: '+75%' },
      { label: 'Accuracy Rate', value: '98%' },
      { label: 'Doctor Efficiency', value: '+40%' },
    ],
  },
  {
    id: '3',
    title: 'PropertyPro: Next-gen AI Real Estate Platform',
    slug: 'propertypro-real-estate-platform',
    category: 'Real Estate',
    description: 'PropertyPro is an innovative AI-assisted real estate platform designed to seamlessly connect buyers, sellers, and renters with their ideal properties.',
    fullDescription: `PropertyPro is an innovative AI-assisted real estate platform designed to seamlessly connect buyers, sellers, and renters with their ideal properties. Developed by Orange Sky Solutions, PropertyPro leverages advanced AI and scalable technologies to bring transparency, trust, and speed to the often-complex real estate market.

The platform aims to simplify property search, enhance user confidence with verified listings, and offer personalized recommendations tailored to individual preferences.

Key features include virtual property tours, AI-powered price predictions, neighborhood insights, and seamless communication between all parties involved in a transaction.`,
    techStack: ['Next.js', 'React', 'Tailwind CSS', 'Node.js'],
    results: [
      { label: 'Search Time', value: '-50%' },
      { label: 'Match Accuracy', value: '92%' },
      { label: 'User Engagement', value: '+120%' },
    ],
  },
];

export const getCaseStudyBySlug = (slug: string): CaseStudy | undefined => {
  return caseStudies.find((study) => study.slug === slug);
};
