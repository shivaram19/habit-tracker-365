# Orange Sky Solutions - Full Stack Website

A complete full-stack website for Orange Sky Solutions, a digital technology company offering AI/MVP development, web/mobile development, cloud engineering, and UI/UX services.

## Project Structure

```
orangesky/
├── frontend/          # React + Vite + TypeScript + Tailwind CSS
│   ├── src/
│   │   ├── components/   # Reusable UI components
│   │   ├── pages/        # Page components
│   │   ├── data/         # Static data files
│   │   └── lib/          # Utilities and API client
│   └── package.json
│
├── backend/           # Node.js + Express + Prisma + PostgreSQL
│   ├── src/
│   │   ├── routes/       # API routes
│   │   ├── middleware/   # Auth, validation, error handling
│   │   ├── validators/   # Zod schemas
│   │   └── lib/          # Prisma client
│   ├── prisma/
│   │   ├── schema.prisma # Database schema
│   │   └── seed.ts       # Database seeding
│   └── package.json
│
└── README.md
```

## Tech Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and building
- **Tailwind CSS** with custom Orange Sky theme
- **React Router DOM** for navigation
- **Framer Motion** for animations
- **React Hook Form + Zod** for form handling
- **Axios** for API calls
- **Lucide React** for icons

### Backend
- **Node.js** with Express.js
- **TypeScript** for type safety
- **Prisma ORM** with PostgreSQL
- **JWT** for authentication
- **Zod** for request validation
- **bcrypt** for password hashing
- **Helmet** & **CORS** for security

## Getting Started

### Prerequisites
- Node.js 18+
- PostgreSQL 14+
- npm or yarn

### Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

The frontend will be available at `http://localhost:5173`

### Backend Setup

1. Install dependencies:
```bash
cd backend
npm install
```

2. Create `.env` file from example:
```bash
cp .env.example .env
```

3. Update `.env` with your database credentials:
```env
DATABASE_URL="postgresql://user:password@localhost:5432/orangesky"
JWT_SECRET="your-secret-key"
```

4. Run database migrations:
```bash
npm run prisma:migrate
```

5. Seed the database:
```bash
npm run prisma:seed
```

6. Start the development server:
```bash
npm run dev
```

The API will be available at `http://localhost:3001`

## Features

### Marketing Website
- ✅ Homepage with hero, services, case studies, blogs
- ✅ 7 Service pages (MVP, Web, Cloud, Data, Mobile, UI/UX, AI)
- ✅ Industries page
- ✅ Careers page with job listings
- ✅ Contact page with form
- ✅ Blog listing and detail pages
- ✅ Privacy Policy & Terms pages
- ✅ Responsive design
- ✅ Animations and transitions

### Admin Dashboard
- ✅ Dashboard with stats overview
- ✅ Blog management (CRUD)
- ✅ Career listings management
- ✅ Contact messages management
- ✅ Role-based access control (RBAC)

### API Endpoints

#### Public
- `GET /api/blogs` - List published blogs
- `GET /api/blogs/:slug` - Get blog by slug
- `GET /api/careers` - List active jobs
- `GET /api/careers/:slug` - Get job by slug
- `POST /api/careers/:id/apply` - Submit application
- `POST /api/contact` - Submit contact message
- `POST /api/contact/newsletter` - Newsletter signup

#### Auth
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/refresh` - Refresh token
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user

#### Admin (Protected)
- `GET /api/admin/dashboard` - Dashboard stats
- `CRUD /api/admin/blogs` - Blog management
- `CRUD /api/admin/jobs` - Job management
- `GET /api/admin/applications` - View applications
- `GET /api/admin/messages` - View messages

## Environment Variables

### Frontend (.env)
```env
VITE_API_URL=http://localhost:3001/api
```

### Backend (.env)
```env
NODE_ENV=development
PORT=3001
DATABASE_URL=postgresql://user:password@localhost:5432/orangesky
JWT_SECRET=your-jwt-secret
JWT_EXPIRES_IN=7d
CORS_ORIGIN=http://localhost:5173
```

## Database Schema

- **User** - Admin users with roles (ADMIN, EDITOR, VIEWER)
- **Blog** - Blog posts with categories and tags
- **BlogCategory** - Blog categories
- **BlogTag** - Blog tags
- **JobListing** - Career opportunities
- **JobApplication** - Job applications
- **CaseStudy** - Portfolio case studies
- **ContactMessage** - Contact form submissions
- **Newsletter** - Newsletter subscribers
- **AuditLog** - Activity logging

## Deployment

### Frontend (Vercel/Netlify)
```bash
cd frontend
npm run build
# Deploy dist/ folder
```

### Backend (Railway/Render/AWS)
```bash
cd backend
npm run build
npm start
```

## Scripts

### Frontend
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint

### Backend
- `npm run dev` - Start with hot reload
- `npm run build` - Compile TypeScript
- `npm start` - Start production server
- `npm run prisma:studio` - Open Prisma Studio
- `npm run prisma:migrate` - Run migrations
- `npm run prisma:seed` - Seed database

## License

Copyright © 2026 Orange Sky Solutions. All rights reserved.
