import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from 'react-native';
import { Modal } from '@/components/shared/Modal';
import { Button } from '@/components/shared/Button';
import { CATEGORIES } from '@/utils/categories';
import { Filter, X, Search } from 'lucide-react-native';

export interface FilterOptions {
  searchQuery: string;
  categoryFilter: number | null;
  minSpend: number | null;
  maxSpend: number | null;
}

interface HistoryFilterProps {
  filters: FilterOptions;
  onFiltersChange: (filters: FilterOptions) => void;
  onClearFilters: () => void;
}

export const HistoryFilter: React.FC<HistoryFilterProps> = ({
  filters,
  onFiltersChange,
  onClearFilters,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [tempFilters, setTempFilters] = useState<FilterOptions>(filters);

  const hasActiveFilters =
    filters.searchQuery ||
    filters.categoryFilter !== null ||
    filters.minSpend !== null ||
    filters.maxSpend !== null;

  const handleOpenModal = () => {
    setTempFilters(filters);
    setShowModal(true);
  };

  const handleApplyFilters = () => {
    onFiltersChange(tempFilters);
    setShowModal(false);
  };

  const handleClearAll = () => {
    setTempFilters({
      searchQuery: '',
      categoryFilter: null,
      minSpend: null,
      maxSpend: null,
    });
  };

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <Search size={20} color="#9CA3AF" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search highlights..."
          value={filters.searchQuery}
          onChangeText={(text) =>
            onFiltersChange({ ...filters, searchQuery: text })
          }
          placeholderTextColor="#9CA3AF"
        />
      </View>

      <TouchableOpacity
        style={[styles.filterButton, hasActiveFilters && styles.filterButtonActive]}
        onPress={handleOpenModal}
      >
        <Filter size={20} color={hasActiveFilters ? '#FFFFFF' : '#6B7280'} />
      </TouchableOpacity>

      {hasActiveFilters && (
        <TouchableOpacity style={styles.clearButton} onPress={onClearFilters}>
          <X size={20} color="#DC2626" />
        </TouchableOpacity>
      )}

      <Modal visible={showModal} onClose={() => setShowModal(false)}>
        <View style={styles.modalContent}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Filter History</Text>
            <TouchableOpacity onPress={() => setShowModal(false)}>
              <X size={24} color="#6B7280" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.modalScroll}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Category</Text>
              <View style={styles.categoryGrid}>
                <TouchableOpacity
                  style={[
                    styles.categoryChip,
                    tempFilters.categoryFilter === null ? styles.categoryChipSelected : styles.categoryChipUnselected
                  ]}
                  onPress={() =>
                    setTempFilters({ ...tempFilters, categoryFilter: null })
                  }
                >
                  <Text
                    style={tempFilters.categoryFilter === null ? styles.categoryTextSelected : styles.categoryText}
                  >
                    All
                  </Text>
                </TouchableOpacity>
                {CATEGORIES.map((cat) => {
                  const isSelected = tempFilters.categoryFilter === cat.id;
                  return (
                    <TouchableOpacity
                      key={cat.id}
                      style={[
                        styles.categoryChip,
                        {
                          backgroundColor: isSelected ? cat.color : '#FFFFFF',
                          borderColor: isSelected ? cat.color : '#D1D5DB',
                        }
                      ]}
                      onPress={() =>
                        setTempFilters({ ...tempFilters, categoryFilter: cat.id })
                      }
                    >
                      <Text style={isSelected ? styles.categoryTextSelected : styles.categoryText}>
                        {cat.name}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Spending Range</Text>
              <View style={styles.rangeRow}>
                <View style={styles.rangeInput}>
                  <Text style={styles.rangeLabel}>Min ($)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="0"
                    value={tempFilters.minSpend?.toString() || ''}
                    onChangeText={(text) =>
                      setTempFilters({
                        ...tempFilters,
                        minSpend: text ? parseFloat(text) : null,
                      })
                    }
                    keyboardType="decimal-pad"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>
                <View style={styles.rangeInput}>
                  <Text style={styles.rangeLabel}>Max ($)</Text>
                  <TextInput
                    style={styles.input}
                    placeholder="1000"
                    value={tempFilters.maxSpend?.toString() || ''}
                    onChangeText={(text) =>
                      setTempFilters({
                        ...tempFilters,
                        maxSpend: text ? parseFloat(text) : null,
                      })
                    }
                    keyboardType="decimal-pad"
                    placeholderTextColor="#9CA3AF"
                  />
                </View>
              </View>
            </View>
          </ScrollView>

          <View style={styles.buttonRow}>
            <View style={styles.buttonHalf}>
              <Button
                title="Clear All"
                onPress={handleClearAll}
                variant="secondary"
              />
            </View>
            <View style={styles.buttonHalf}>
              <Button
                title="Apply"
                onPress={handleApplyFilters}
              />
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
  },
  filterButton: {
    padding: 10,
    borderRadius: 8,
    backgroundColor: '#F3F4F6',
  },
  filterButtonActive: {
    backgroundColor: '#3B82F6',
  },
  clearButton: {
    padding: 10,
  },
  modalContent: {
    maxHeight: '80%',
    padding: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#111827',
  },
  modalScroll: {
    maxHeight: 400,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  categoryChip: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
  },
  categoryChipSelected: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  categoryChipUnselected: {
    backgroundColor: '#FFFFFF',
    borderColor: '#D1D5DB',
  },
  categoryText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  categoryTextSelected: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  rangeRow: {
    flexDirection: 'row',
    gap: 12,
  },
  rangeInput: {
    flex: 1,
  },
  rangeLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
    color: '#111827',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  buttonHalf: {
    flex: 1,
  },
});
