import { LoginScreen } from '@/components/screens/LoginScreen';

export default function Login() {
  return <LoginScreen />;
}
