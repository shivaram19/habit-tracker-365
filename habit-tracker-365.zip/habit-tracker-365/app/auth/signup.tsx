import { SignupScreen } from '@/components/screens/SignupScreen';

export default function Signup() {
  return <SignupScreen />;
}
